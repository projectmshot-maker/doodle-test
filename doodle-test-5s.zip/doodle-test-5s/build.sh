#!/bin/bash
# one-time: npm install && npx playwright install chromium   (ffmpeg must exist)
cat engine.js doodle.js shots.js > film.js
node film-render.js board     # storyboard -> board/sheet.jpg  (check this first)
node film-render.js all       # -> final.mp4 (~5.5s, silent)
