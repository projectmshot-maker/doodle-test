// doodle.js — round-head "doodle" characters (CurioDoodle / Blobby style)
// Build:  cat engine.js doodle.js shots.js > film.js
// Uses engine internals (M, SPH, basic, hex, ACT, PI, T) — must come AFTER engine.js.

function doodleFace(g, o) {
  g.clearRect(0, 0, 512, 512);
  const ink = o.ink ?? '#2b1616', k = o.k ?? 1, cx = 256;
  const ex = o.ex ?? 96, ey = o.ey ?? 228, my = o.my ?? 340;
  const lx = (o.lx ?? 0) * 9, ly = (o.ly ?? 0) * 7;
  g.lineCap = 'round'; g.lineJoin = 'round'; g.strokeStyle = ink; g.fillStyle = ink;
  const eye = x => {
    const t = !o.eyes || o.eyes === 'normal' ? 'dot' : o.eyes;
    g.fillStyle = ink; g.strokeStyle = ink;
    if (t === 'dot') { g.beginPath(); g.ellipse(x + lx, ey + ly, 20 * k, 27 * k, 0, 0, 2 * PI); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(x + lx + 6 * k, ey + ly - 9 * k, 6 * k, 0, 2 * PI); g.fill(); }
    if (t === 'sleepy') { g.lineWidth = 16 * k; g.beginPath(); g.moveTo(x - 40 * k, ey - 8 * k); g.lineTo(x + 40 * k, ey - 8 * k); g.stroke(); g.beginPath(); g.arc(x + lx, ey - 6 * k, 21 * k, 0, PI); g.fill(); }
    if (t === 'wide') { g.fillStyle = '#fff'; g.lineWidth = 9; g.beginPath(); g.ellipse(x, ey, 38 * k, 44 * k, 0, 0, 2 * PI); g.fill(); g.stroke(); g.fillStyle = ink; g.beginPath(); g.arc(x + lx, ey + ly, 14 * k, 0, 2 * PI); g.fill(); }
    if (t === 'happy') { g.lineWidth = 15 * k; g.beginPath(); g.arc(x, ey + 16, 30 * k, PI * 1.1, PI * 1.9); g.stroke(); }
    if (t === 'closed') { g.lineWidth = 15 * k; g.beginPath(); g.moveTo(x - 32 * k, ey); g.lineTo(x + 32 * k, ey); g.stroke(); }
  };
  eye(cx - ex); eye(cx + ex);
  const br = o.brow;
  if (br) {
    g.lineWidth = 19 * k; const by = ey - 66 * k;
    for (const s of [-1, 1]) {
      const x = cx + s * ex; let yi = 0, yo = 0;
      if (br === 'up') yi = yo = -20; if (br === 'angry') { yi = 20; yo = -10; } if (br === 'sad') { yi = -20; yo = 10; } if (br === 'flat') yi = yo = 6;
      if (br === 'smug') { yi = s < 0 ? -22 : 6; yo = s < 0 ? -22 : 6; }
      g.beginPath(); g.moveTo(x - s * 38 * k, by + yi); g.lineTo(x + s * 38 * k, by + yo); g.stroke();
    }
  }
  if (o.blush) { g.fillStyle = 'rgba(255,110,130,0.5)'; for (const s of [-1, 1]) { g.beginPath(); g.ellipse(cx + s * 150, ey + 62, 30, 17, 0, 0, 2 * PI); g.fill(); } }
  g.fillStyle = ink; g.strokeStyle = ink; g.lineWidth = 13 * k;
  const m = o.mouth ?? 'smile';
  if (m === 'smile') { g.beginPath(); g.arc(cx, my - 38, 52 * k, PI * 0.18, PI * 0.82); g.stroke(); }
  if (m === 'frown') { g.beginPath(); g.arc(cx, my + 40, 48 * k, PI * 1.2, PI * 1.8); g.stroke(); }
  if (m === 'flat') { g.beginPath(); g.moveTo(cx - 44 * k, my); g.lineTo(cx + 44 * k, my); g.stroke(); }
  if (m === 'smirk') { g.beginPath(); g.moveTo(cx - 40 * k, my + 6); g.quadraticCurveTo(cx + 10, my + 10, cx + 52 * k, my - 14); g.stroke(); }
  if (m === 'talk') { g.beginPath(); g.ellipse(cx, my, 38 * k, 20 * k, 0, 0, 2 * PI); g.fill(); }
  if (m === 'o') { g.beginPath(); g.ellipse(cx, my, 22 * k, 30 * k, 0, 0, 2 * PI); g.fill(); }
  if (m === 'blob') { g.lineWidth = 12 * k; g.fillStyle = 'rgba(255,255,255,0.6)'; g.beginPath(); g.moveTo(cx - 52 * k, my - 6); g.bezierCurveTo(cx - 40 * k, my - 30 * k, cx + 30 * k, my - 24 * k, cx + 56 * k, my - 4); g.bezierCurveTo(cx + 50 * k, my + 40 * k, cx + 4, my + 44 * k, cx - 10, my + 30 * k); g.bezierCurveTo(cx - 40 * k, my + 36 * k, cx - 60 * k, my + 20 * k, cx - 52 * k, my - 6); g.closePath(); g.fill(); g.stroke(); }
  if (m === 'open' || m === 'laugh') { const h = m === 'laugh' ? 70 : 48; g.beginPath(); g.moveTo(cx - 62 * k, my - 14); g.quadraticCurveTo(cx, my - 24, cx + 62 * k, my - 14); g.quadraticCurveTo(cx + 48 * k, my + h * k, cx, my + h * k); g.quadraticCurveTo(cx - 48 * k, my + h * k, cx - 62 * k, my - 14); g.closePath(); g.fill(); g.fillStyle = '#e0606a'; g.beginPath(); g.ellipse(cx, my + h * k - 14, 26 * k, 12 * k, 0, 0, 2 * PI); g.fill(); }
  if (m === 'tongue') { g.beginPath(); g.moveTo(cx - 44 * k, my); g.lineTo(cx + 44 * k, my); g.stroke(); g.fillStyle = '#f07a8a'; g.beginPath(); g.arc(cx + 8, my + 4, 24 * k, 0, PI); g.fill(); g.stroke(); }
  if (o.mustache) {
    g.fillStyle = o.mustache; g.strokeStyle = o.mustacheLine ?? '#6a2a18'; g.lineWidth = 10;
    for (const s of [-1, 1]) { g.beginPath(); g.moveTo(cx, my - 62); g.bezierCurveTo(cx + s * 50, my - 100, cx + s * 135, my - 96, cx + s * 168, my - 40); g.bezierCurveTo(cx + s * 120, my - 62, cx + s * 52, my - 52, cx, my - 46); g.closePath(); g.fill(); g.stroke(); }
  }
  if (o.sweat) { g.fillStyle = '#7cc8ff'; g.strokeStyle = ink; g.lineWidth = 6; g.beginPath(); g.moveTo(420, 120); g.quadraticCurveTo(446, 168, 420, 180); g.quadraticCurveTo(394, 168, 420, 120); g.fill(); g.stroke(); }
  if (o.tear) { g.fillStyle = 'rgba(80,170,255,0.95)'; for (const s of [-1, 1]) g.fillRect(cx + s * ex - 8, ey + 28, 16, 120); }
}

// doodle({ name, skin, shirt, pants, hat:'bowler'|'fedora'|'cap'|null, hatCol, headR, defaults:{mustache,...} })
function doodle(o = {}) {
  const skin = o.skin ?? 0xffd9a8, R = o.headR ?? 0.8, LEG = 0.8, LIMB = 0x17181f;
  const root = new THREE.Group(); root.name = o.name;
  const hips = new THREE.Group(); hips.position.y = LEG + 0.06; root.add(hips);
  const legs = [], knees = [];
  for (const s of [1, -1]) {
    const p = new THREE.Group(); p.position.set(0.14 * s, 0, 0); hips.add(p);
    const th = M(new THREE.CapsuleGeometry(0.045, LEG * 0.46, 4, 8), LIMB, 0); th.position.y = -LEG * 0.27; p.add(th);
    const kn = new THREE.Group(); kn.position.y = -LEG * 0.5; p.add(kn);
    const sh = M(new THREE.CapsuleGeometry(0.045, LEG * 0.46, 4, 8), LIMB, 0); sh.position.y = -LEG * 0.27; kn.add(sh);
    const ft = M(SPH(0.1, 12), o.shoe ?? 0x17181f, 0.012); ft.scale.set(1, 0.6, 1.5); ft.position.set(0, -LEG * 0.56, 0.06); kn.add(ft);
    legs.push(p); knees.push(kn);
  }
  const torso = new THREE.Group(); hips.add(torso);
  const body = M(SPH(0.4, 20), o.shirt ?? 0x7a5fa0, 0.03); body.scale.set(1, 1.1, 0.75); body.position.y = 0.42; torso.add(body);
  const arms = [], hands = [];
  for (const s of [1, -1]) {
    const p = new THREE.Group(); p.position.set(0.3 * s, 0.7, 0); torso.add(p);
    const a = M(new THREE.CapsuleGeometry(0.04, 0.62, 4, 8), LIMB, 0); a.position.y = -0.36; p.add(a);
    const h = M(SPH(0.1, 12), o.hand ?? 0xf4f4f4, 0.02); h.position.y = -0.74; p.add(h);
    const mk = new THREE.Group(); mk.position.y = -0.78; p.add(mk); arms.push(p); hands.push(mk);
  }
  const head = new THREE.Group(); head.position.y = 0.72; torso.add(head);
  const skull = new THREE.Group(); skull.position.y = R * 0.92; skull.scale.set(1.06, 0.97, 0.95); head.add(skull);
  skull.add(M(SPH(R, 32), skin, 0.035));
  // face patch curved on the sphere (no floating plane)
  const c = document.createElement('canvas'); c.width = c.height = 512;
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 4;
  const patch = new THREE.Mesh(new THREE.SphereGeometry(R * 1.012, 40, 32, PI / 2 - 0.62, 1.24, PI / 2 - 0.62, 1.24), basic(0xffffff, { map: tex, transparent: true, alphaTest: 0.05 }));
  skull.add(patch);
  const hc = o.hatCol ?? 0x2a1c1c;
  if (o.hat) {
    const hat = new THREE.Group(); hat.position.y = R * 0.74; skull.add(hat);
    if (o.hat === 'bowler' || o.hat === 'fedora') {
      const dome = M(new THREE.SphereGeometry(R * 0.62, 24, 14, 0, 2 * PI, 0, PI / 2), hc, 0.025); dome.scale.y = o.hat === 'bowler' ? 0.9 : 0.8; hat.add(dome);
      const br = M(new THREE.CylinderGeometry(R * (o.hat === 'bowler' ? 0.86 : 1.0), R * (o.hat === 'bowler' ? 0.86 : 1.0), 0.05, 28), hc, 0.025); hat.add(br);
      const bd = M(new THREE.CylinderGeometry(R * 0.635, R * 0.635, 0.1, 28), o.bandCol ?? 0x9a6a3a, 0.01); bd.position.y = 0.06; hat.add(bd);
    }
    if (o.hat === 'cap') {
      const dome = M(new THREE.SphereGeometry(R * 0.7, 24, 14, 0, 2 * PI, 0, PI / 2), hc, 0.025); hat.add(dome);
      const vs = M(RB(R * 1.0, 0.05, R * 0.6, 0.03), hc, 0.02); vs.position.set(0, 0.04, R * 0.62); hat.add(vs);
    }
  }
  const rig = { root, hips, torso, head, hm: skull, arms, hands, legs, knees, kind: 'doodle', defaults: o.defaults ?? {} };
  rig.pose = (p = {}) => {
    arms[0].rotation.set(p.aLx ?? 0, 0, p.aLz ?? 0.12); arms[1].rotation.set(p.aRx ?? 0, 0, -(p.aRz ?? 0.12));
    const sit = p.sit ? 1 : 0;
    legs[0].rotation.set((p.lL ?? 0) - sit * 1.5, 0, p.lLz ?? 0); legs[1].rotation.set((p.lR ?? 0) - sit * 1.5, 0, -(p.lRz ?? 0));
    knees[0].rotation.x = (p.kL ?? 0) + sit * 1.5; knees[1].rotation.x = (p.kR ?? 0) + sit * 1.5;
    torso.rotation.set(p.tx ?? 0, p.ty ?? 0, p.tz ?? 0); head.rotation.set(p.hx ?? 0, p.hy ?? 0, p.hz ?? 0);
    hips.position.y = LEG + 0.06 + (p.y ?? 0) - sit * 0.42;
  };
  const bs = hash(ACT.length + 31);
  rig.face = o2 => {
    o2 = { ...rig.defaults, ...(o2 || {}) };
    if ((!o2.eyes || o2.eyes === 'normal') && ((T * 0.45 + bs) % 1) < 0.045) o2.eyes = 'closed';
    doodleFace(c.getContext('2d'), o2); tex.needsUpdate = true;
  };
  rig.face({}); rig.pose(); ACT.push(rig); return rig;
}

// Ready-made looks matching the reference screenshots
const doodlePresets = {
  curio: () => doodle({ name: 'curio', skin: 0xffd9a8, shirt: 0x6a4a3a, hat: 'bowler', hatCol: 0x2a1c1c, bandCol: 0x9a6a3a, defaults: { mustache: '#b8702f', brow: 'angry', mouth: 'tongue' } }),
  blobby: () => doodle({ name: 'blobby', skin: 0xececec, shirt: 0x7a5fa0, defaults: { eyes: 'sleepy', brow: 'smug', mouth: 'blob', ey: 232 } }),
};
