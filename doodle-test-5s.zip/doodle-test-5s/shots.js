// ===== 5s doodle test: Curio + Blobby ("Time be like..." gag) =====
const curio = doodlePresets.curio(), blobby = doodlePresets.blobby();
const chair = new THREE.Group();
{ const wood = 0x6a3a14; const seat = M(RB(0.8, 0.1, 0.7, 0.03), wood, 0.02); seat.position.y = 0.33; chair.add(seat);
  const back = M(RB(0.8, 0.8, 0.08, 0.03), wood, 0.02); back.position.set(0, 0.75, -0.34); chair.add(back);
  for (const sx of [1, -1]) for (const sz of [1, -1]) { const l = M(RB(0.07, 0.33, 0.07, 0.02), wood, 0.015); l.position.set(0.34 * sx, 0.165, 0.28 * sz); chair.add(l); } }
scene.add(chair); PROPS.push(chair);
ACT.forEach(a => scene.add(a.root));

const S = [];
const shot = (t0, t1, fn) => S.push({ t0, t1, fn });

shot(0.00, 1.80, (u, t, k) => { // Curio close-up, talking
  put(curio, 0, 0, 0, 0.1); curio.pose({ aRx: -0.9 + Math.sin(t * 7) * 0.15, hz: 0.05 });
  curio.face({ brow: 'angry', mouth: talk(t), eyes: 'dot' });
  return { cam: mv(headBox(curio), k, { yaw: 0.25, pitch: 0.05, zoom: 1.25, fov: 32 }, { yaw: 0.05, zoom: 1.1 }, 1) };
});
shot(1.80, 3.40, (u, t, k) => { // Blobby bored on a chair
  put(chair, 0, 0, 0, 0); put(blobby, 0, 0, 0.02, 0);
  blobby.pose({ sit: 1, hz: -0.12, hx: 0.08, aLx: -0.2, aRx: -1.0, aRz: 0.4 });
  blobby.face({ mouth: k > 0.2 && k < 0.85 ? 'blob' : 'blob', eyes: 'sleepy', brow: 'smug' });
  return { cam: mv(boxOf([blobby, chair]), k, { yaw: -0.45, pitch: 0.08, zoom: 1.15, fov: 36 }, { yaw: 0.2, zoom: 1.0 }, 1) };
});
shot(3.40, 5.00, (u, t, k) => { // both, wide, Curio talks
  put(curio, -1.0, 0, 0.3, 0.7); curio.pose({ aLx: -1.1 + Math.sin(t * 8) * 0.2, hz: -0.05 }); curio.face({ brow: 'angry', mouth: talk(t) });
  put(chair, 0.9, 0, 0, -0.5); put(blobby, 0.9, 0, 0.02, -0.5);
  blobby.pose({ sit: 1, hz: 0.1, aRx: -0.6 }); blobby.face({ eyes: 'sleepy', brow: 'smug', mouth: 'blob' });
  return { cam: mv(boxOf([curio, blobby, chair]), k, { yaw: 0.1, pitch: 0.12, zoom: 1.1, fov: 40 }, { yaw: -0.15, zoom: 1.0 }) };
});

const END = AUDIO_DUR, DUR = Math.round((AUDIO_DUR + 0.5) * 100) / 100;
window.SHOT_COUNT = S.length;
window.SHOTS = S.map(s => [s.t0, s.t1]);
window.DUR = DUR;
function draw(t) {
  T = t; octx.setTransform(1.5, 0, 0, 1.5, 0, 0);
  if (t >= END) { octx.fillStyle = '#000'; octx.fillRect(0, 0, W, H); return; }
  let s = S.find(s => t >= s.t0 && t < s.t1) || S[S.length - 1];
  reset(); const u = t - s.t0, k = cl(u / (s.t1 - s.t0)); const r = s.fn(u, t, k);
  ACT.forEach((a, i) => { if ((a.kind === 'human' || a.kind === 'doodle') && a.root.visible) a.head.rotation.z += Math.sin(t * 1.6 + i) * 0.035; });
  applyCam(r.cam); renderer.render(scene, camera);
  octx.drawImage(renderer.domElement, 0, 0, W, H); vignette(); r.fx && r.fx(); caption(t);
}
window.renderFrame = t => { draw(t); return out.toDataURL('image/jpeg', 0.92); };
window.renderShot = (i, tt) => { const s = S[i - 1]; return window.renderFrame(tt ?? (s.t0 + s.t1) / 2); };
document.fonts.load('900 60px InterB').then(() => { window.ready = true; });
