// ---------- motion helpers (copied from example) ----------
const ss = x => x <= 0 ? 0 : x >= 1 ? 1 : x * x * (3 - 2 * x);
const cl = x => Math.max(0, Math.min(1, x));
const DEF = { yaw: 0, pitch: 0.1, zoom: 1, fov: 35, roll: 0 };
function mv(box, k, a, b = {}, hand = 0) {
  const q = ss(k), o = {};
  for (const key in DEF) { const va = a[key] ?? DEF[key], vb = b[key] ?? va; o[key] = va + (vb - va) * q; }
  if (hand) { o.yaw += Math.sin(T * 1.3) * 0.025 * hand; o.pitch += Math.sin(T * 1.7 + 1) * 0.018 * hand; }
  return fit(box, o);
}
const envAt = t => ENV[Math.min(ENV.length - 1, Math.max(0, Math.round(t * 30)))];
const talk = t => { const e = envAt(t); return e > 0.42 ? 'talk' : e > 0.14 ? 'o' : 'flat'; };
