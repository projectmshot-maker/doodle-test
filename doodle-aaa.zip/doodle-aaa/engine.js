import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { BokehPass } from 'three/addons/postprocessing/BokehPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { WORDS, CHUNKS, ENV, AUDIO_DUR } from './data.js';
let T = 0;

const W = 720, H = 1280, V3 = THREE.Vector3, PI = Math.PI;
const out = document.getElementById('out'), octx = out.getContext('2d');
const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setSize(W * 1.5, H * 1.5); renderer.setPixelRatio(1);
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.12;
renderer.outputColorSpace = THREE.SRGBColorSpace;
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(35, W / H, 0.05, 800);

// ---------- AAA pipeline: IBL + HDR MSAA target + DOF + bloom + filmic grade ----------
const FX = !new URLSearchParams(location.search).has('nofx');
let composer = null, bokehPass = null, gradePass = null;
const GradeShader = {
  uniforms: { tDiffuse: { value: null }, time: { value: 0 }, grain: { value: 0.03 }, vig: { value: 0.30 }, ca: { value: 0.004 }, sat: { value: 1.12 }, con: { value: 1.08 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
  fragmentShader: `uniform sampler2D tDiffuse; uniform float time, grain, vig, ca, sat, con; varying vec2 vUv;
float h(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
void main(){
  vec2 d = vUv - 0.5; float r2 = dot(d, d);
  vec3 c; c.r = texture2D(tDiffuse, vUv + d * r2 * ca).r; c.g = texture2D(tDiffuse, vUv).g; c.b = texture2D(tDiffuse, vUv - d * r2 * ca).b;
  float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
  c = mix(vec3(l), c, sat);
  c = (c - 0.5) * con + 0.5;
  c += vec3(0.020, 0.010, -0.012) * smoothstep(0.5, 1.0, l) + vec3(-0.012, 0.0, 0.022) * (1.0 - smoothstep(0.0, 0.45, l));
  c *= 1.0 - vig * smoothstep(0.25, 0.95, length(d) * 1.4);
  c += (h(vUv * vec2(1080.0, 1920.0) + time) - 0.5) * grain;
  gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}`
};
try {
  if (FX) {
    const pm = new THREE.PMREMGenerator(renderer); scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture; scene.environmentIntensity = 0.45;
    const RW = W * 1.5, RH = H * 1.5;
    const rt = new THREE.WebGLRenderTarget(RW, RH, { type: THREE.HalfFloatType, samples: 4 });
    composer = new EffectComposer(renderer, rt); composer.setSize(RW, RH);
    composer.addPass(new RenderPass(scene, camera));
    bokehPass = new BokehPass(scene, camera, { focus: 6, aperture: 0.0005, maxblur: 0.012 }); composer.addPass(bokehPass);
    composer.addPass(new UnrealBloomPass(new THREE.Vector2(RW, RH), 0.28, 0.55, 0.92));
    composer.addPass(new OutputPass());
    gradePass = new ShaderPass(GradeShader); composer.addPass(gradePass);
  }
} catch (err) { console.log('[fx] disabled:', err.message); composer = null; }
function renderFX(c) {
  if (!composer) { renderer.render(scene, camera); return; }
  if (c) bokehPass.uniforms.focus.value = Math.max(0.5, c.pos.distanceTo(c.look));
  gradePass.uniforms.time.value = (T * 37.0) % 100.0; composer.render();
}
// PBR upgrade of the environment (characters stay toon + outline, like the references)
const pbrCache = new Map();
function pbrOf(m) {
  if (pbrCache.has(m)) return pbrCache.get(m);
  const s = new THREE.MeshStandardMaterial({ color: m.color.clone(), roughness: 0.82, metalness: 0.02, envMapIntensity: 0.6 });
  s.onBeforeCompile = sh => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWp;').replace('#include <begin_vertex>', '#include <begin_vertex>\nvWp = (modelMatrix * vec4(transformed, 1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>
varying vec3 vWp;
float hh(vec3 p){ p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
float vn(vec3 x){ vec3 i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(mix(hh(i), hh(i + vec3(1.0, 0.0, 0.0)), f.x), mix(hh(i + vec3(0.0, 1.0, 0.0)), hh(i + vec3(1.0, 1.0, 0.0)), f.x), f.y),
             mix(mix(hh(i + vec3(0.0, 0.0, 1.0)), hh(i + vec3(1.0, 0.0, 1.0)), f.x), mix(hh(i + vec3(0.0, 1.0, 1.0)), hh(i + vec3(1.0, 1.0, 1.0)), f.x), f.y), f.z); }`)
      .replace('#include <color_fragment>', `#include <color_fragment>
{ float n = vn(vWp * 1.7) * 0.5 + vn(vWp * 6.3) * 0.3 + vn(vWp * 23.0) * 0.2; diffuseColor.rgb *= mix(0.72, 1.14, n); }`);
  };
  s.customProgramCacheKey = () => 'pbrnoise1';
  pbrCache.set(m, s); return s;
}
let townUpgraded = false;
function upgradeTown() {
  if (townUpgraded || !FX) return; townUpgraded = true;
  town.traverse(o => { if (!o.isMesh) return; if (o.userData.ol) { o.visible = false; return; } if (o.material && o.material.isMeshToonMaterial) o.material = pbrOf(o.material); });
}
const hash = n => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };

// ---------- look ----------
const grad = (() => { const t = new THREE.DataTexture(new Uint8Array([95, 165, 225, 255]), 4, 1, THREE.RedFormat); t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true; return t; })();
const mc = {}; const toon = c => mc[c] ??= new THREE.MeshToonMaterial({ color: c, gradientMap: grad });
const oc = {};
function olMat(th) {
  if (oc[th]) return oc[th];
  const m = new THREE.MeshBasicMaterial({ color: 0x17181f, side: THREE.BackSide });
  m.onBeforeCompile = s => { s.vertexShader = s.vertexShader.replace('#include <begin_vertex>', `vec3 transformed = position + normalize(normal) * ${th.toFixed(4)};`); };
  m.customProgramCacheKey = () => 'ol' + th; return oc[th] = m;
}
function M(geo, c, th = 0.025, mat) {
  const m = new THREE.Mesh(geo, mat || toon(c)); m.castShadow = true; m.receiveShadow = true;
  if (th > 0) { const o = new THREE.Mesh(geo, olMat(th)); o.castShadow = false; o.userData.ol = true; m.add(o); }
  return m;
}
const RB = (w, h, d, r = 0.08) => new RoundedBoxGeometry(w, h, d, 3, Math.min(r, w / 2 - 0.002, h / 2 - 0.002, d / 2 - 0.002));
const SPH = (r, s = 20) => new THREE.SphereGeometry(r, s, Math.round(s * 0.75));
const basic = (c, o = {}) => new THREE.MeshBasicMaterial({ color: c, ...o });
function canvasTex(w, h, draw) { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t; }
function sign(text, w, h, bg, fg, px, dbl = false) {
  const tex = canvasTex(1024, Math.round(1024 * h / w), (g, cw, ch) => {
    g.fillStyle = bg; g.fillRect(0, 0, cw, ch); g.strokeStyle = '#2a1d12'; g.lineWidth = 18; g.strokeRect(9, 9, cw - 18, ch - 18);
    g.fillStyle = fg; g.font = `900 ${px}px ThaiB, InterB, Arial Black, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, cw / 2, ch / 2 + 6);
  });
  const mat = basic(0xc8c8c8, { map: tex, side: dbl ? THREE.DoubleSide : THREE.FrontSide });
  const grp = new THREE.Group(); const a = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat); grp.add(a);
  if (dbl) { const b = new THREE.Mesh(new THREE.PlaneGeometry(w, h), basic(0xc8c8c8, { map: tex })); b.rotation.y = PI; b.position.z = -0.01; grp.add(b); a.material = basic(0xc8c8c8, { map: tex }); }
  return grp;
}

// ---------- faces ----------
function drawFace(g, o, lidCol) {
  g.clearRect(0, 0, 256, 256);
  const ey = o.ey ?? 104, ex = o.ex ?? 50, k = o.k ?? 1;
  const eye = (x, s) => {
    const t = o.eyes ?? 'normal';
    g.fillStyle = '#16161c'; g.strokeStyle = '#16161c'; g.lineCap = 'round';
    if (t === 'happy') { g.lineWidth = 11 * k; g.beginPath(); g.arc(x, ey + 10, 18 * k, PI * 1.1, PI * 1.9); g.stroke(); return; }
    if (t === 'closed') { g.lineWidth = 10 * k; g.beginPath(); g.moveTo(x - 18 * k, ey); g.lineTo(x + 18 * k, ey); g.stroke(); return; }
    if (t === 'wide') { g.fillStyle = '#fff'; g.beginPath(); g.ellipse(x, ey, 27 * k, 31 * k, 0, 0, 2 * PI); g.fill(); g.lineWidth = 5; g.stroke(); g.fillStyle = '#16161c'; g.beginPath(); g.arc(x + (o.lx ?? 0) * 8, ey + (o.ly ?? 0) * 8, 11 * k, 0, 2 * PI); g.fill(); return; }
    g.beginPath(); g.ellipse(x + (o.lx ?? 0) * 5, ey + (o.ly ?? 0) * 5, 14 * k, 21 * k, 0, 0, 2 * PI); g.fill();
    g.fillStyle = '#fff'; g.beginPath(); g.arc(x + (o.lx ?? 0) * 5 + 4 * k, ey - 8 * k, 5 * k, 0, 2 * PI); g.fill();
    if (t === 'half') { g.fillStyle = lidCol; g.fillRect(x - 24 * k, ey - 30 * k, 48 * k, 28 * k); g.fillStyle = '#16161c'; g.fillRect(x - 20 * k, ey - 4 * k, 40 * k, 7 * k); }
  };
  eye(128 - ex, -1); eye(128 + ex, 1);
  const br = o.brow; g.strokeStyle = '#16161c'; g.lineWidth = 10 * k; g.lineCap = 'round';
  const by = ey - 42 * k;
  if (br) {
    for (const s of [-1, 1]) {
      const x = 128 + s * ex; let yi = 0, yo = 0;
      if (br === 'up') yi = yo = -12; if (br === 'angry') { yi = 12; yo = -6; } if (br === 'sad') { yi = -12; yo = 6; } if (br === 'flat') yi = yo = 6;
      g.beginPath(); g.moveTo(x - s * 20 * k, by + yi); g.lineTo(x + s * 20 * k, by + yo); g.stroke();
    }
  }
  if (o.blush) { g.fillStyle = 'rgba(255,110,130,0.55)'; for (const s of [-1, 1]) { g.beginPath(); g.ellipse(128 + s * 72, ey + 40, 18, 10, 0, 0, 2 * PI); g.fill(); } }
  const my = o.my ?? 176, m = o.mouth ?? 'smile';
  g.fillStyle = '#3a1418'; g.strokeStyle = '#16161c'; g.lineWidth = 9 * k;
  if (m === 'smile') { g.beginPath(); g.arc(128, my - 22, 30 * k, PI * 0.2, PI * 0.8); g.stroke(); }
  if (m === 'frown') { g.beginPath(); g.arc(128, my + 24, 28 * k, PI * 1.2, PI * 1.8); g.stroke(); }
  if (m === 'flat') { g.beginPath(); g.moveTo(128 - 26 * k, my); g.lineTo(128 + 26 * k, my); g.stroke(); }
  if (m === 'wavy') { g.beginPath(); for (let i = 0; i <= 6; i++) { const x = 128 - 30 * k + i * 10 * k, y = my + (i % 2 ? -6 : 6); i ? g.lineTo(x, y) : g.moveTo(x, y); } g.stroke(); }
  if (m === 'o') { g.beginPath(); g.ellipse(128, my, 13 * k, 17 * k, 0, 0, 2 * PI); g.fill(); g.stroke(); }
  if (m === 'talk') { g.beginPath(); g.ellipse(128, my, 22 * k, 11 * k, 0, 0, 2 * PI); g.fill(); g.stroke(); }
  if (m === 'grin' || m === 'laugh' || m === 'open') {
    const hgt = m === 'grin' ? 20 : m === 'laugh' ? 40 : 30;
    g.beginPath(); g.moveTo(128 - 40 * k, my - 10); g.quadraticCurveTo(128, my - 16, 128 + 40 * k, my - 10); g.quadraticCurveTo(128 + 30 * k, my + hgt * k, 128, my + hgt * k); g.quadraticCurveTo(128 - 30 * k, my + hgt * k, 128 - 40 * k, my - 10); g.closePath(); g.fill(); g.stroke();
    g.fillStyle = '#fff'; g.fillRect(128 - 30 * k, my - 10, 60 * k, 9 * k);
    if (m !== 'grin') { g.fillStyle = '#e0606a'; g.beginPath(); g.ellipse(128, my + hgt * k - 9, 16 * k, 7 * k, 0, 0, 2 * PI); g.fill(); }
  }
  if (o.tear) { g.fillStyle = 'rgba(80,170,255,0.95)'; for (const s of [-1, 1]) { g.fillRect(128 + s * ex - 7, ey + 16, 14, 90); } }
  if (o.sweat) { g.fillStyle = '#7cc8ff'; g.strokeStyle = '#16161c'; g.lineWidth = 4; g.beginPath(); g.moveTo(206, 40); g.quadraticCurveTo(222, 72, 206, 80); g.quadraticCurveTo(190, 72, 206, 40); g.fill(); g.stroke(); }
  if (o.bandage) { g.save(); g.translate(190, 56); g.rotate(0.6); g.fillStyle = '#f0c9a0'; g.strokeStyle = '#7a5a3a'; g.lineWidth = 4; for (const r of [0, PI / 2]) { g.save(); g.rotate(r); g.fillRect(-36, -11, 72, 22); g.strokeRect(-36, -11, 72, 22); g.restore(); } g.restore(); }
}
function faceSlot(size, z, y = 0, lid = '#f1c27d') {
  const c = document.createElement('canvas'); c.width = c.height = 256; const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(size, size), basic(0xffffff, { map: tex, transparent: true, alphaTest: 0.05 }));
  mesh.position.set(0, y, z);
  const set = (o = {}) => { drawFace(c.getContext('2d'), o, lid); tex.needsUpdate = true; };
  set(); return { mesh, set };
}

// ---------- characters ----------
const hex = c => '#' + c.toString(16).padStart(6, '0');
const ACT = [];
function human(o) {
  const skin = o.skin ?? 0xf1c27d, root = new THREE.Group(); root.name = o.name;
  const hips = new THREE.Group(); hips.position.y = 1.05; root.add(hips);
  const legs = [];
  for (const s of [1, -1]) {
    const p = new THREE.Group(); p.position.set(0.25 * s, 0, 0); hips.add(p);
    const leg = M(RB(0.46, 1.0, 0.48, 0.1), o.pants); leg.position.y = -0.46; p.add(leg);
    const sh = M(RB(0.5, 0.2, 0.64, 0.08), o.shoe ?? 0x2a2a2e); sh.position.set(0, -0.95, 0.07); p.add(sh); legs.push(p);
  }
  const torso = new THREE.Group(); hips.add(torso);
  const body = M(RB(1.02, 1.0, 0.58, 0.14), o.shirt); body.position.y = 0.5; torso.add(body);
  if (o.sash) { const sa = M(RB(0.16, 1.2, 0.62, 0.04), o.sash, 0.015); sa.position.set(0, 0.5, 0.01); sa.rotation.z = 0.7; torso.add(sa); }
  if (o.hoodie) { const hd = M(RB(0.9, 0.3, 0.4, 0.12), o.shirt); hd.position.set(0, 1.0, -0.22); torso.add(hd); const pk = M(RB(0.6, 0.26, 0.06, 0.04), o.hoodie, 0.012); pk.position.set(0, 0.24, 0.3); torso.add(pk); }
  const arms = [], hands = [];
  for (const s of [1, -1]) {
    const p = new THREE.Group(); p.position.set(0.74 * s, 0.9, 0); torso.add(p);
    const a = M(RB(0.42, 0.88, 0.44, 0.12), o.sleeve ?? o.shirt); a.position.y = -0.36; p.add(a);
    const h = M(RB(0.38, 0.26, 0.4, 0.1), skin); h.position.y = -0.9; p.add(h);
    const mk = new THREE.Group(); mk.position.y = -1.0; p.add(mk); arms.push(p); hands.push(mk);
  }
  const head = new THREE.Group(); head.position.y = 1.0; torso.add(head);
  const hm = M(RB(0.86, 0.82, 0.82, 0.22), skin); hm.position.y = 0.43; head.add(hm);
  const face = faceSlot(0.78, 0.418, 0.42, hex(skin)); head.add(face.mesh);
  const hair = o.hair ?? 0x4a2e1a, hs = o.hairStyle ?? 'messy';
  if (hs !== 'none') {
    const top = M(RB(0.94, 0.26, 0.9, 0.12), hair); top.position.set(0, 0.88, -0.02); head.add(top);
    const back = M(RB(0.94, 0.56, 0.24, 0.1), hair); back.position.set(0, 0.62, -0.36); head.add(back);
    if (hs === 'messy') for (let i = 0; i < 4; i++) { const f = M(RB(0.26, 0.22, 0.22, 0.08), hair); f.position.set(-0.33 + i * 0.22, 0.8, 0.36); f.rotation.z = (i - 1.5) * 0.15; head.add(f); }
    if (hs === 'slick') { const f = M(RB(0.94, 0.14, 0.3, 0.06), hair); f.position.set(0, 0.84, 0.3); head.add(f); }
    if (hs === 'long') { for (const s of [1, -1]) { const l = M(RB(0.2, 1.0, 0.5, 0.08), hair); l.position.set(0.47 * s, 0.32, -0.12); head.add(l); } const bk = M(RB(0.94, 1.1, 0.24, 0.1), hair); bk.position.set(0, 0.28, -0.38); head.add(bk); const fr = M(RB(0.94, 0.16, 0.24, 0.06), hair); fr.position.set(0, 0.8, 0.34); head.add(fr); }
    if (hs === 'bun') { const b = M(SPH(0.24), hair); b.position.set(0, 1.0, -0.3); head.add(b); const fr = M(RB(0.94, 0.16, 0.24, 0.06), hair); fr.position.set(0, 0.8, 0.34); head.add(fr); }
  }
  let hat = null;
  if (o.hat === 'top') { hat = new THREE.Group(); const br = M(new THREE.CylinderGeometry(0.62, 0.62, 0.06, 24), 0x1d1d26); hat.add(br); const cr = M(new THREE.CylinderGeometry(0.4, 0.42, 0.62, 24), 0x1d1d26); cr.position.y = 0.32; hat.add(cr); const bd = M(new THREE.CylinderGeometry(0.425, 0.425, 0.12, 24), 0xc0392b, 0); bd.position.y = 0.1; hat.add(bd); hat.position.y = 0.88; head.add(hat); }
  const party = new THREE.Group(); { const cone = M(new THREE.ConeGeometry(0.26, 0.62, 18), o.partyCol ?? 0xff4fa3, 0.02); cone.position.y = 0.31; party.add(cone); const pom = M(SPH(0.09), 0xffe14a, 0.015); pom.position.y = 0.64; party.add(pom); party.position.set(0.12, 1.0, 0); party.rotation.z = -0.2; party.visible = false; head.add(party); }
  const rig = { root, hips, torso, head, hm, arms, hands, legs, party, kind: 'human' };
  rig.pose = (p = {}) => {
    arms[0].rotation.set(p.aLx ?? 0, 0, p.aLz ?? 0.07); arms[1].rotation.set(p.aRx ?? 0, 0, -(p.aRz ?? 0.07));
    legs[0].rotation.set(p.lL ?? 0, 0, p.lLz ?? 0); legs[1].rotation.set(p.lR ?? 0, 0, -(p.lRz ?? 0));
    torso.rotation.set(p.tx ?? 0, p.ty ?? 0, p.tz ?? 0); head.rotation.set(p.hx ?? 0, p.hy ?? 0, p.hz ?? 0);
    hips.position.y = 1.05 + (p.y ?? 0);
  };
  const bs = hash(ACT.length + 11);
  rig.face = o2 => { o2 = { ...(o2 || {}) }; if ((!o2.eyes || o2.eyes === 'normal') && ((T * 0.45 + bs) % 1) < 0.045) o2.eyes = 'closed'; face.set(o2); }; rig.pose(); ACT.push(rig); return rig;
}
function rockGeo(r) {
  let g = new THREE.IcosahedronGeometry(r, 3); g.deleteAttribute('normal'); g.deleteAttribute('uv'); g = mergeVertices(g);
  const p = g.attributes.position, v = new V3();
  for (let i = 0; i < p.count; i++) {
    v.fromBufferAttribute(p, i); const n = v.clone().normalize();
    const f = 1 + 0.09 * Math.sin(n.x * 4 + 1) * Math.sin(n.y * 3.3 + 2) + 0.06 * Math.sin(n.z * 5 + n.x * 2) + 0.04 * Math.sin(n.y * 9);
    v.multiplyScalar(f); v.x *= 1.22; v.y *= 0.82; v.z *= 1.0; if (v.y < -r * 0.55) v.y = -r * 0.55 + (v.y + r * 0.55) * 0.2;
    p.setXYZ(i, v.x, v.y, v.z);
  }
  g.computeVertexNormals(); return g;
}
const ROCKC = 0x8d9097;
function makeRock(r = 0.32, withFace = true) {
  const root = new THREE.Group(); const m = M(rockGeo(r), ROCKC, r * 0.075); m.position.y = r * 0.5; root.add(m);
  const rig = { root, kind: 'rock', r };
  if (withFace) { const f = faceSlot(r * 1.5, r * 1.06, r * 0.56, hex(0x9a9ea5)); root.add(f.mesh); rig.face = o => f.set({ eyes: 'half', mouth: 'flat', ex: 46, ey: 112, my: 172, brow: null, ...o }); rig.face(); }
  ACT.push(rig); return rig;
}
function eyes3(parent, x, y, z, r, pupil = 0x111111) {
  for (const s of [1, -1]) { const w = M(SPH(r, 14), 0xffffff, r * 0.12); w.position.set(x * s, y, z); parent.add(w); const p = M(SPH(r * 0.55, 12), pupil, 0); p.position.set(x * s, y, z + r * 0.62); parent.add(p); }
}
function wingShape(len, h) { const s = new THREE.Shape(); s.moveTo(0, 0); s.lineTo(len * 0.45, h); s.lineTo(len, h * 0.85); s.lineTo(len * 0.8, h * 0.35); s.lineTo(len * 0.6, h * 0.45); s.lineTo(len * 0.45, 0.05); s.lineTo(0, -h * 0.15); return new THREE.ShapeGeometry(s); }
function makeDragon() {
  const root = new THREE.Group(), red = 0xd8443a, belly = 0xf3c46b;
  const body = M(SPH(0.36), red); body.scale.set(1, 0.95, 1.2); body.position.y = 0.5; root.add(body);
  const bl = M(SPH(0.27), belly, 0.015); bl.scale.set(1, 1.05, 0.7); bl.position.set(0, 0.48, 0.2); root.add(bl);
  const head = new THREE.Group(); head.position.set(0, 0.98, 0.22); root.add(head);
  const hm = M(RB(0.56, 0.48, 0.52, 0.18), red); head.add(hm);
  const sn = M(RB(0.4, 0.26, 0.32, 0.1), red); sn.position.set(0, -0.08, 0.34); head.add(sn);
  for (const s of [1, -1]) { const nh = M(SPH(0.03, 8), 0x3a1010, 0); nh.position.set(0.08 * s, -0.02, 0.5); head.add(nh); const hn = M(new THREE.ConeGeometry(0.07, 0.26, 10), 0xf8e8c0, 0.015); hn.position.set(0.17 * s, 0.32, -0.08); hn.rotation.x = -0.4; head.add(hn); }
  eyes3(head, 0.14, 0.08, 0.24, 0.085);
  const tears = new THREE.Group(); for (const s of [1, -1]) { const t = new THREE.Mesh(new THREE.CapsuleGeometry(0.035, 0.5, 4, 8), basic(0x6ab8ff)); t.position.set(0.32 * s, -0.05, 0.25); t.rotation.z = 1.2 * s; tears.add(t); const t2 = t.clone(); t2.position.set(0.5 * s, -0.25, 0.25); t2.rotation.z = 0.6 * s; tears.add(t2); } tears.visible = false; head.add(tears);
  const wings = [];
  for (const s of [1, -1]) { const p = new THREE.Group(); p.position.set(0.22 * s, 0.75, -0.1); const w = M(wingShape(0.85, 0.5), 0xb33228, 0.012, new THREE.MeshToonMaterial({ color: 0xb33228, gradientMap: grad, side: THREE.DoubleSide })); w.scale.x = s; p.add(w); p.rotation.y = -0.3 * s; root.add(p); wings.push(p); }
  const tail = M(new THREE.ConeGeometry(0.13, 0.85, 12), red); tail.rotation.x = -PI / 2 - 0.4; tail.position.set(0, 0.32, -0.6); root.add(tail);
  for (const s of [1, -1]) { const l = M(RB(0.14, 0.3, 0.16, 0.05), red, 0.015); l.position.set(0.17 * s, 0.14, 0.05); root.add(l); }
  const fire = new THREE.Group(); { const a = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.8, 14), basic(0xff7a1a, { transparent: true, opacity: 0.95 })); a.rotation.x = PI / 2; a.position.z = 0.4; fire.add(a); const b = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.5, 12), basic(0xffe45a)); b.rotation.x = PI / 2; b.position.z = 0.3; fire.add(b); } fire.position.set(0, -0.08, 0.5); fire.rotation.x = 0.5; fire.visible = false; head.add(fire);
  const rig = { root, head, wings, fire, tears, kind: 'dragon' };
  rig.pose = (p = {}) => { wings.forEach((w, i) => { const s = i ? -1 : 1; w.rotation.set(0, -0.3 * s, (p.wing ?? 0.4) * s); }); head.rotation.set(p.hx ?? 0, p.hy ?? 0, 0); fire.visible = !!p.fire; tears.visible = !!p.tears; };
  rig.pose(); ACT.push(rig); return rig;
}
function makeGriffin() {
  const root = new THREE.Group(), tan = 0xc99a5b, white = 0xf4f1ea;
  const body = M(new THREE.CapsuleGeometry(0.55, 1.2, 8, 16), tan, 0.03); body.rotation.x = PI / 2; body.position.y = 1.35; root.add(body);
  const chest = M(SPH(0.55), white, 0.03); chest.position.set(0, 1.55, 0.75); root.add(chest);
  const legs = [];
  for (const [x, z] of [[0.35, 0.8], [-0.35, 0.8], [0.35, -0.75], [-0.35, -0.75]]) { const p = new THREE.Group(); p.position.set(x, 1.15, z); const l = M(new THREE.CapsuleGeometry(0.15, 0.85, 4, 10), z > 0 ? white : tan, 0.025); l.position.y = -0.6; p.add(l); const paw = M(RB(0.3, 0.16, 0.34, 0.07), z > 0 ? 0xe0a43a : tan, 0.02); paw.position.set(0, -1.1, 0.06); p.add(paw); root.add(p); legs.push(p); }
  const head = new THREE.Group(); head.position.set(0, 2.25, 1.05); root.add(head);
  const hm = M(SPH(0.42), white, 0.03); head.add(hm);
  const beak = M(new THREE.ConeGeometry(0.14, 0.42, 14), 0xf2b51c, 0.02); beak.rotation.x = PI / 2 + 0.35; beak.position.set(0, -0.08, 0.46); head.add(beak);
  eyes3(head, 0.16, 0.08, 0.32, 0.1);
  const crest = M(new THREE.ConeGeometry(0.12, 0.4, 10), white, 0.02); crest.position.set(0, 0.35, -0.25); crest.rotation.x = -0.9; head.add(crest);
  const wings = []; for (const s of [1, -1]) { const p = new THREE.Group(); p.position.set(0.4 * s, 1.75, 0.3); const w = M(wingShape(1.6, 0.9), 0x8a5a2e, 0.02, new THREE.MeshToonMaterial({ color: 0x8a5a2e, gradientMap: grad, side: THREE.DoubleSide })); w.scale.x = s; p.add(w); p.rotation.y = -1.2 * s; root.add(p); wings.push(p); }
  const tail = M(new THREE.CylinderGeometry(0.05, 0.07, 1.0, 8), tan, 0.015); tail.position.set(0, 1.5, -1.3); tail.rotation.x = -0.8; root.add(tail);
  const tuft = M(SPH(0.14), 0x6a4422, 0.015); tuft.position.set(0, 1.85, -1.7); root.add(tuft);
  const rig = { root, head, legs, wings, kind: 'griffin' };
  rig.pose = (p = {}) => { const g = p.gallop ?? 0; legs[0].rotation.x = g; legs[1].rotation.x = g * 0.6; legs[2].rotation.x = -g; legs[3].rotation.x = -g * 0.6; wings.forEach((w, i) => { const s = i ? -1 : 1; w.rotation.set(0, -1.2 * s, (p.wing ?? 0.15) * s); }); head.rotation.set(p.hx ?? 0, p.hy ?? 0, 0); root.children[0].position.y = 1.35; };
  rig.pose(); ACT.push(rig); return rig;
}
function makeCritter(kind) {
  const root = new THREE.Group(); const C = { cat: [0x9aa0aa, 0xffffff], owl: [0x8a5a34, 0xe8d0a8], fox: [0xe8782a, 0xffffff], bunny: [0xf4f0f4, 0xffc2d2], hamster: [0xe9a24c, 0xfff2dc] }[kind];
  const sz = kind === 'hamster' ? 0.42 : 1;
  const body = M(SPH(0.3 * sz), C[0], 0.022 * sz); body.scale.set(1, 1, 1.1); body.position.y = 0.3 * sz; root.add(body);
  const head = new THREE.Group(); head.position.set(0, (kind === 'owl' || kind === 'hamster' ? 0.5 : 0.68) * sz, 0.12 * sz); root.add(head);
  const hm = M(SPH((kind === 'owl' ? 0.3 : 0.25) * sz), C[0], 0.022 * sz); head.add(hm);
  const bel = M(SPH(0.2 * sz), C[1], 0.012 * sz); bel.scale.set(1, 1, 0.6); bel.position.set(0, 0.26 * sz, 0.17 * sz); root.add(bel);
  const ear = (x, y, z, len, w, rx = 0) => { const e = M(new THREE.ConeGeometry(w * sz, len * sz, 10), C[0], 0.015 * sz); e.position.set(x * sz, y * sz, z * sz); e.rotation.set(rx, 0, -Math.sign(x) * 0.25); head.add(e); };
  if (kind === 'cat') { ear(0.15, 0.24, 0, 0.18, 0.09); ear(-0.15, 0.24, 0, 0.18, 0.09); }
  if (kind === 'fox') { ear(0.15, 0.26, 0, 0.26, 0.1); ear(-0.15, 0.26, 0, 0.26, 0.1); const t = M(SPH(0.2), C[0], 0.02); t.scale.set(0.8, 0.8, 2); t.position.set(0, 0.35, -0.45); root.add(t); const tt = M(SPH(0.12), 0xffffff, 0.015); tt.position.set(0, 0.42, -0.78); root.add(tt); const sn = M(new THREE.ConeGeometry(0.1, 0.22, 10), C[0], 0.015); sn.rotation.x = PI / 2; sn.position.set(0, -0.05, 0.28); head.add(sn); }
  if (kind === 'bunny') { for (const s of [1, -1]) { const e = M(new THREE.CapsuleGeometry(0.06, 0.4, 4, 10), C[0], 0.015); e.position.set(0.09 * s, 0.42, -0.02); e.rotation.z = -0.15 * s; head.add(e); } }
  if (kind === 'owl') { ear(0.2, 0.25, 0, 0.14, 0.07); ear(-0.2, 0.25, 0, 0.14, 0.07); const bk = M(new THREE.ConeGeometry(0.05, 0.12, 8), 0xf0a020, 0.01); bk.rotation.x = PI / 2 + 0.5; bk.position.set(0, -0.06, 0.29); head.add(bk); }
  if (kind === 'hamster') { for (const s of [1, -1]) { const e = M(SPH(0.04), C[0], 0.008); e.position.set(0.08 * s, 0.1, 0); head.add(e); } }
  const f = faceSlot((kind === 'owl' ? 0.5 : 0.42) * sz, (kind === 'owl' ? 0.27 : 0.235) * sz, 0.02 * sz, hex(C[0])); head.add(f.mesh);
  const wings = [];
  if (kind === 'cat' || kind === 'owl') for (const s of [1, -1]) { const p = new THREE.Group(); p.position.set(0.2 * s, 0.42, -0.05); const w = M(wingShape(0.5, 0.3), kind === 'cat' ? 0xffffff : 0x6a4426, 0.01, new THREE.MeshToonMaterial({ color: kind === 'cat' ? 0xffffff : 0x6a4426, gradientMap: grad, side: THREE.DoubleSide })); w.scale.x = s; p.add(w); p.rotation.y = -0.5 * s; root.add(p); wings.push(p); }
  const rig = { root, head, kind };
  rig.face = o => f.set({ ex: 46, ey: 112, my: 168, k: 1.25, mouth: 'o', ...o });
  rig.pose = (p = {}) => { wings.forEach((w, i) => { const s = i ? -1 : 1; w.rotation.set(0, -0.5 * s, (p.wing ?? 0.5) * s); }); head.rotation.set(p.hx ?? 0, p.hy ?? 0, p.hz ?? 0); };
  rig.face({ eyes: 'normal', mouth: 'smile' }); rig.pose(); ACT.push(rig); return rig;
}
function makeRobot() {
  const root = new THREE.Group(), metal = 0x8794aa, dark = 0x3c4558, acc = 0xe8a22a, T = 0.07;
  const hips = new THREE.Group(); hips.position.y = 6.6; root.add(hips);
  const pel = M(RB(3.2, 1.2, 2.2, 0.3), dark, T); hips.add(pel);
  const legs = [];
  for (const s of [1, -1]) { const p = new THREE.Group(); p.position.set(1.3 * s, -0.3, 0); hips.add(p); const th = M(RB(1.4, 3.0, 1.6, 0.3), metal, T); th.position.y = -1.6; p.add(th); const kn = M(SPH(0.75), dark, T); kn.position.y = -3.2; p.add(kn); const sh = M(RB(1.7, 2.8, 1.9, 0.3), metal, T); sh.position.y = -4.6; p.add(sh); const ft = M(RB(2.0, 0.7, 3.0, 0.25), dark, T); ft.position.set(0, -6.0, 0.4); p.add(ft); const st = M(RB(1.75, 0.3, 0.2, 0.05), acc, 0.04); st.position.set(0, -4.0, 0.96); p.add(st); legs.push(p); }
  const torso = new THREE.Group(); torso.position.y = 0.4; hips.add(torso);
  const ch = M(RB(4.4, 4.0, 2.7, 0.45), metal, T); ch.position.y = 2.2; torso.add(ch);
  const core = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.6, 0.2, 28), basic(0x6ff4ff)); core.rotation.x = PI / 2; core.position.set(0, 2.5, 1.36); torso.add(core);
  const plate = M(RB(3.4, 0.4, 0.3, 0.1), acc, 0.04); plate.position.set(0, 3.7, 1.3); torso.add(plate);
  const head = new THREE.Group(); head.position.y = 4.3; torso.add(head);
  const hm = M(RB(2.3, 1.7, 2.1, 0.35), metal, T); hm.position.y = 0.85; head.add(hm);
  const vis = new THREE.Mesh(RB(1.9, 0.5, 0.15, 0.07), basic(0xff3b3b)); vis.position.set(0, 0.95, 1.06); head.add(vis);
  const ant = M(new THREE.CylinderGeometry(0.06, 0.06, 1.0, 8), dark, 0.03); ant.position.set(0.7, 2.1, 0); head.add(ant); const tip = new THREE.Mesh(SPH(0.16), basic(0xff3b3b)); tip.position.set(0.7, 2.65, 0); head.add(tip);
  const arms = [];
  for (const s of [1, -1]) { const p = new THREE.Group(); p.position.set(2.75 * s, 3.6, 0); torso.add(p); const sp = M(SPH(0.85), dark, T); p.add(sp); const up = M(RB(1.1, 2.6, 1.2, 0.25), metal, T); up.position.y = -1.5; p.add(up); const lo = M(RB(1.35, 2.5, 1.45, 0.25), metal, T); lo.position.y = -3.9; p.add(lo); const cn = M(new THREE.CylinderGeometry(0.4, 0.5, 0.9, 16), dark, T); cn.position.y = -5.5; p.add(cn); arms.push(p); }
  const rig = { root, hips, legs, torso, head, arms, kind: 'robot' };
  rig.pose = (p = {}) => { legs[0].rotation.set(p.lL ?? 0, 0, 0); legs[1].rotation.set(p.lR ?? 0, 0, 0); arms[0].rotation.set(p.aLx ?? 0, 0, p.aLz ?? 0.1); arms[1].rotation.set(p.aRx ?? 0, 0, -(p.aRz ?? 0.1)); torso.rotation.set(p.tx ?? 0, p.ty ?? 0, 0); head.rotation.set(p.hx ?? 0, 0, 0); };
  rig.pose(); ACT.push(rig); return rig;
}

// ---------- town ----------
const town = new THREE.Group(); scene.add(town);
const sky = new THREE.Mesh(new THREE.SphereGeometry(400, 32, 16), basic(0xffffff, { side: THREE.BackSide, fog: false })); scene.add(sky);
const skyTex = {};
for (const [k, top, mid, bot] of [['day', '#3e98e6', '#8fcaf2', '#e4f4fb'], ['gold', '#e9774a', '#f6a865', '#ffe2b0'], ['atk', '#3a0c16', '#8c1e22', '#ef5a2e']]) {
  skyTex[k] = canvasTex(16, 512, (g, w, h) => { const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, top); gr.addColorStop(0.42, mid); gr.addColorStop(0.5, bot); gr.addColorStop(1, bot); g.fillStyle = gr; g.fillRect(0, 0, w, h); });
}
const hemi = new THREE.HemisphereLight(0xffffff, 0x806a50, 1.0); scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffffff, 2.2); sun.castShadow = true; sun.shadow.mapSize.set(4096, 4096);
Object.assign(sun.shadow.camera, { left: -32, right: 32, top: 32, bottom: -32, near: 1, far: 120 }); sun.shadow.bias = -0.0005; sun.shadow.normalBias = 0.03; scene.add(sun); scene.add(sun.target);
const rim = new THREE.PointLight(0xffd9a0, 0, 12, 1.5); scene.add(rim);
function mood(k) {
  sky.material.map = skyTex[k]; sky.material.needsUpdate = true;
  const L = { day: [0xcfe9ff, 0x8a7a5a, 1.15, 0xffffff, 2.3, [18, 30, 16]], gold: [0xffd3a0, 0x6a4c36, 1.0, 0xffc07c, 2.2, [-22, 14, 14]], atk: [0xff8a70, 0x3a1c1c, 0.85, 0xff6a44, 1.9, [-14, 22, -12]] }[k];
  hemi.color.set(L[0]); hemi.groundColor.set(L[1]); hemi.intensity = L[2]; sun.color.set(L[3]); sun.intensity = L[4]; sun.position.set(...L[5]); sun.target.position.set(0, 0, 0);
  renderer.toneMappingExposure = k === 'atk' ? 1.05 : 1.12;
}
const cob = canvasTex(512, 512, (g, w) => { g.fillStyle = '#b9a98f'; g.fillRect(0, 0, w, w); let n = 0; for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) { n++; const l = 62 + hash(n) * 12; g.fillStyle = `hsl(32,${18 + hash(n + 9) * 10}%,${l}%)`; g.beginPath(); g.roundRect(x * 64 + (y % 2) * 32 + 4 - 32, y * 64 + 4, 56, 56, 14); g.fill(); g.beginPath(); g.roundRect(x * 64 + (y % 2) * 32 + 4 + 480, y * 64 + 4, 56, 56, 14); g.fill(); } });
cob.wrapS = cob.wrapT = THREE.RepeatWrapping; cob.repeat.set(40, 40);
const ground = new THREE.Mesh(new THREE.PlaneGeometry(160, 160), new THREE.MeshToonMaterial({ color: 0xffffff, map: cob, gradientMap: grad })); ground.rotation.x = -PI / 2; ground.receiveShadow = true; town.add(ground);
const plaza = new THREE.Mesh(new THREE.CircleGeometry(10, 48), toon(0xd8ccb4)); plaza.rotation.x = -PI / 2; plaza.position.y = 0.01; plaza.receiveShadow = true; town.add(plaza);
const lawn = new THREE.Mesh(new THREE.PlaneGeometry(12, 12), toon(0x7cc35a)); lawn.rotation.x = -PI / 2; lawn.position.set(8.5, 0.02, 6); lawn.receiveShadow = true; town.add(lawn);
// academy
const acad = new THREE.Group(); acad.position.set(0, 0, -24); town.add(acad);
{ const b = M(RB(18, 9, 6, 0.3), 0xeadfc8, 0.06); b.position.y = 4.5; acad.add(b); const r = M(RB(19.4, 1.1, 7, 0.3), 0xb8473a, 0.06); r.position.y = 9.4; acad.add(r);
  for (let i = 0; i < 6; i++) { const c = M(new THREE.CylinderGeometry(0.38, 0.42, 7.2, 16), 0xffffff, 0.04); c.position.set(-7 + i * 2.8, 3.6, 3.4); acad.add(c); }
  const d = M(RB(3, 4.6, 0.4, 0.1), 0x2c4a7c, 0.04); d.position.set(0, 2.3, 3.05); acad.add(d);
  const s = sign('PET ACADEMY', 9, 1.5, '#2c4a7c', '#ffd34a', 150); s.position.set(0, 7.6, 3.08); acad.add(s);
  const tw = M(RB(4.2, 4.2, 4.2, 0.3), 0xeadfc8, 0.06); tw.position.set(0, 11.9, 0); acad.add(tw); const tr = M(new THREE.ConeGeometry(3.3, 2.6, 4), 0xb8473a, 0.06); tr.rotation.y = PI / 4; tr.position.set(0, 15.3, 0); acad.add(tr);
}
const clockCanvas = document.createElement('canvas'); clockCanvas.width = clockCanvas.height = 256; const clockTex = new THREE.CanvasTexture(clockCanvas); clockTex.colorSpace = THREE.SRGBColorSpace;
function drawClock(h, m) { const g = clockCanvas.getContext('2d'); g.clearRect(0, 0, 256, 256); g.fillStyle = '#fffaf0'; g.beginPath(); g.arc(128, 128, 120, 0, 2 * PI); g.fill(); g.lineWidth = 12; g.strokeStyle = '#2a2a33'; g.stroke(); for (let i = 0; i < 12; i++) { const a = i / 12 * 2 * PI; g.fillStyle = '#2a2a33'; g.fillRect(128 + Math.sin(a) * 96 - 5, 128 - Math.cos(a) * 96 - 5, 10, 10); } const hand = (a, l, w) => { g.lineWidth = w; g.lineCap = 'round'; g.beginPath(); g.moveTo(128, 128); g.lineTo(128 + Math.sin(a) * l, 128 - Math.cos(a) * l); g.stroke(); }; hand(h / 12 * 2 * PI, 58, 12); hand(m / 60 * 2 * PI, 88, 8); clockTex.needsUpdate = true; }
drawClock(9, 0);
const clock = new THREE.Mesh(new THREE.CircleGeometry(1.6, 40), basic(0xcfcfcf, { map: clockTex })); clock.position.set(0, 11.9, -21.85); town.add(clock);
// shops
const shopCols = [0xf08a7a, 0x8ec5e8, 0xf6d36b, 0xa4d98a, 0xd7a6e8, 0xf4b07a];
let sn = 0;
function shop(x, z, ry) { sn++; const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = ry; const h = 5 + hash(sn) * 3; const b = M(RB(6, h, 5.4, 0.25), shopCols[sn % 6], 0.05); b.position.y = h / 2; g.add(b); const rf = M(RB(6.4, 0.6, 5.8, 0.2), 0x6b4a3a, 0.05); rf.position.y = h + 0.2; g.add(rf); const aw = M(RB(5.2, 0.25, 1.4, 0.08), [0xe84a4a, 0x2f8f5a, 0x3a6fd0][sn % 3], 0.03); aw.position.set(0, 3.2, 3.2); aw.rotation.x = 0.35; g.add(aw); const win = M(RB(3.6, 1.8, 0.1, 0.05), 0x3a5878, 0.02); win.position.set(0, 1.6, 2.72); g.add(win); const dr = M(RB(1.1, 2.4, 0.1, 0.05), 0x5a3a28, 0.02); dr.position.set(2.2, 1.2, 2.73); g.add(dr); town.add(g); }
for (let i = 0; i < 6; i++) { shop(-17, -16 + i * 6.6, PI / 2); shop(17, -16 + i * 6.6, -PI / 2); }
for (let i = 0; i < 6; i++) shop(-16 + i * 6.6, 28, PI);
function tree(x, z, s = 1) { const g = new THREE.Group(); g.position.set(x, 0, z); g.scale.setScalar(s); const t = M(new THREE.CylinderGeometry(0.3, 0.4, 2.4, 10), 0x7a5232, 0.04); t.position.y = 1.2; g.add(t); const a = M(SPH(1.5), 0x5aa84a, 0.05); a.position.y = 3.2; g.add(a); const b = M(SPH(1.1), 0x6cbc54, 0.045); b.position.set(0.6, 4.1, 0.3); g.add(b); town.add(g); return g; }
tree(14, 12);tree(-12, 11); tree(-12, -13); tree(12, -13);
for (const [x, z] of [[-9, 8], [9, -9], [-9, -9]]) { const p = M(new THREE.CylinderGeometry(0.1, 0.14, 4.2, 8), 0x2a2a33, 0.03); p.position.set(x, 2.1, z); town.add(p); const l = new THREE.Mesh(SPH(0.32, 14), basic(0xfff2c4)); l.position.set(x, 4.4, z); town.add(l); }
// fountain
const fountain = new THREE.Group(); fountain.position.set(0, 0, -6); town.add(fountain);
{ const b = M(new THREE.CylinderGeometry(2.4, 2.6, 0.7, 36), 0xbdb6a8, 0.05); b.position.y = 0.35; fountain.add(b); const w = new THREE.Mesh(new THREE.CylinderGeometry(2.15, 2.15, 0.1, 36), toon(0x7cc8f0)); w.position.y = 0.66; fountain.add(w); const p = M(new THREE.CylinderGeometry(0.3, 0.42, 1.8, 16), 0xbdb6a8, 0.04); p.position.y = 1.3; fountain.add(p); const bw = M(new THREE.CylinderGeometry(1.0, 0.45, 0.4, 24), 0xbdb6a8, 0.04); bw.position.y = 2.3; fountain.add(bw); }
const drops = new THREE.Group(); for (let i = 0; i < 18; i++) { const d = new THREE.Mesh(SPH(0.09, 8), basic(0xa8dcff)); const a = i / 18 * 2 * PI; d.position.set(Math.cos(a) * (0.6 + hash(i) * 0.9), 2.6 + hash(i + 3) * 0.6, Math.sin(a) * (0.6 + hash(i) * 0.9)); drops.add(d); } fountain.add(drops);
// PET DAY banner
const banner = new THREE.Group(); banner.position.set(0, 0, -11); town.add(banner);
{ for (const s of [1, -1]) { const p = M(new THREE.CylinderGeometry(0.12, 0.14, 6.6, 10), 0x6b4a3a, 0.03); p.position.set(4.6 * s, 3.3, 0); banner.add(p); } const sg = sign('PET DAY!', 8.6, 1.6, '#ff5b8a', '#ffffff', 220); sg.position.y = 5.6; banner.add(sg);
  for (let i = 0; i < 12; i++) { const f = new THREE.Mesh(new THREE.ConeGeometry(0.25, 0.5, 3), toon(shopCols[i % 6])); f.rotation.x = PI; f.position.set(-4.4 + i * 0.8, 4.45 - Math.sin(i / 11 * PI) * 0.35, 0); banner.add(f); } }
// race
const race = new THREE.Group(); town.add(race);
{ const ln = new THREE.Mesh(new THREE.PlaneGeometry(11, 0.5), basic(0xffffff)); ln.rotation.x = -PI / 2; ln.position.set(0, 0.03, 2); race.add(ln); for (const s of [1, -1]) { const p = M(new THREE.CylinderGeometry(0.14, 0.16, 5.6, 10), 0xffffff, 0.03); p.position.set(5.8 * s, 2.8, 2); race.add(p); } const sg = sign('PET RACE', 11.2, 1.4, '#1f7a4a', '#ffffff', 170, true); sg.position.set(0, 5.1, 2); sg.rotation.y = PI; race.add(sg); }
// park bench(es)
function bench(x, z, ry = 0, s = 1) { const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = ry; g.scale.setScalar(s); const seat = M(RB(2.6, 0.16, 0.75, 0.05), 0xa66a3a, 0.025); seat.position.y = 0.86; g.add(seat); const bk = M(RB(2.6, 0.6, 0.12, 0.05), 0xa66a3a, 0.025); bk.position.set(0, 1.4, -0.34); g.add(bk); for (const sx of [1, -1]) for (const sz of [1, -1]) { const l = M(RB(0.12, 0.86, 0.12, 0.03), 0x2a2a33, 0.015); l.position.set(1.1 * sx, 0.43, 0.28 * sz); g.add(l); } town.add(g); return g; }
const bench1 = bench(8, 4.2); const bench2 = bench(-7, 5, 0, 0.8);
const ROCK_ON_BENCH = new V3(7.6, 0.95, 4.25);
// podium
const podium = new THREE.Group(); podium.position.set(-6, 0, -1); town.add(podium);
{ const pf = M(RB(3, 0.4, 2.4, 0.08), 0x6b4a3a, 0.03); pf.position.y = 0.2; podium.add(pf); const lc = M(RB(1.4, 1.35, 0.7, 0.1), 0x2f5fa8, 0.03); lc.position.set(0, 1.07, 0.7); podium.add(lc); const st = sign('MAYOR', 1.2, 0.36, '#ffd34a', '#2f5fa8', 220); st.position.set(0, 1.2, 1.06); podium.add(st); }
// pedestal / statue
const ped = new THREE.Group(); ped.position.set(0, 0, -6); town.add(ped);
{ const b = M(RB(3.2, 2.0, 3.2, 0.12), 0xd2cbbd, 0.05); b.position.y = 1.0; ped.add(b); const t = M(RB(3.7, 0.3, 3.7, 0.08), 0xc0b8a8, 0.05); t.position.y = 2.15; ped.add(t); const pl = sign('DWAYNE', 2.0, 0.6, '#c9952a', '#3a2408', 230); pl.position.set(0, 1.1, 1.62); ped.add(pl); }
const statue = M(rockGeo(1.5), ROCKC, 0.1); statue.position.set(0, 2.3 + 0.75, -6); town.add(statue);
const drape = M(new THREE.ConeGeometry(2.0, 3.8, 24, 1, true), 0xc0392b, 0.06, new THREE.MeshToonMaterial({ color: 0xc0392b, gradientMap: grad, side: THREE.DoubleSide })); drape.position.set(0, 2.3 + 1.9, -6); town.add(drape);
// props
const PROPS = [];
const prop = o => { PROPS.push(o); return o; };
const gift = prop(new THREE.Group()); { const b = M(RB(0.72, 0.55, 0.72, 0.05), 0xe84a7a, 0.02); b.position.y = 0.27; gift.add(b); const r1 = M(RB(0.14, 0.56, 0.74, 0.02), 0xffd34a, 0.01); r1.position.y = 0.27; gift.add(r1); const lid = new THREE.Group(); lid.position.set(0, 0.56, -0.36); const lm = M(RB(0.78, 0.14, 0.78, 0.04), 0xe84a7a, 0.02); lm.position.z = 0.36; lid.add(lm); gift.add(lid); gift.userData.lid = lid; const gl = new THREE.Mesh(SPH(0.5, 16), basic(0xfff3a0, { transparent: true, opacity: 0.35 })); gl.position.y = 0.75; gift.add(gl); gift.userData.glow = gl; }
const debris = prop(new THREE.Group()); for (let i = 0; i < 46; i++) { const s = 0.5 + hash(i) * 1.6; const m = M(RB(s, s * (0.5 + hash(i + 1)), s * (0.6 + hash(i + 2) * 0.8), 0.15), [0x8794aa, 0x3c4558, 0xe8a22a][i % 3], 0.05); const a = hash(i + 5) * 2 * PI, e = hash(i + 6) * 1.3, r = 2.5 + hash(i + 7) * 8; m.position.set(Math.cos(a) * Math.cos(e) * r, 1 + Math.sin(e) * r, Math.sin(a) * Math.cos(e) * r * 0.7); m.rotation.set(hash(i + 8) * 6, hash(i + 9) * 6, 0); debris.add(m); }
{ for (let i = 0; i < 9; i++) { const p = new THREE.Mesh(SPH(1.2 + hash(i + 40) * 1.4, 16), toon(i % 2 ? 0x6a6a74 : 0x8a8a92)); p.position.set((hash(i + 41) - 0.5) * 7, 1 + hash(i + 42) * 5, (hash(i + 43) - 0.5) * 4); debris.add(p); } const fb = new THREE.Mesh(SPH(3, 24), basic(0xffb040, { transparent: true, opacity: 0.85 })); fb.position.y = 2.5; debris.add(fb); const fc = new THREE.Mesh(SPH(1.9, 20), basic(0xfff2a0)); fc.position.y = 2.5; debris.add(fc); }
const pebbles = prop(new THREE.Group()); for (let i = 0; i < 20; i++) { const p = M(SPH(0.07 + hash(i + 70) * 0.08, 8), 0x8d8d92, 0.01); p.position.set((hash(i + 71) - 0.5) * 7, 0.2 + hash(i + 72) * 0.9, (hash(i + 73) - 0.5) * 7); pebbles.add(p); }
const leaf = prop(new THREE.Mesh(new THREE.CircleGeometry(0.16, 8), toon(0x5aa84a))); leaf.scale.set(1, 0.5, 1);
const fly = prop(new THREE.Group());

// ---------- cast ----------
const guy = human({ name: 'guy', shirt: 0x3d7be0, hoodie: 0x2c5fb8, pants: 0x2b2f3a, hair: 0x4a2e1a, hairStyle: 'messy' });
const pal = human({ name: 'friend', shirt: 0xd8473b, pants: 0x34302c, hair: 0x15151a, hairStyle: 'slick', skin: 0xc68a5a, partyCol: 0x34c3ff });
const mayor = human({ name: 'mayor', shirt: 0x2a2a40, pants: 0x2a2a40, hair: 0x9a9aa0, hairStyle: 'slick', hat: 'top', sash: 0xc0392b, skin: 0xf0c49a });
const EX = [
  human({ shirt: 0xf2c94c, pants: 0x3b5b8a, hair: 0x7a3a1a, hairStyle: 'long', skin: 0xf6d0b0, partyCol: 0x6ee06e }),
  human({ shirt: 0x9b59b6, pants: 0x2b2f3a, hair: 0x15151a, hairStyle: 'bun', skin: 0x8d5a3a, partyCol: 0xffb030 }),
  human({ shirt: 0x2ecc71, pants: 0x4a3a2a, hair: 0xd9a441, hairStyle: 'messy', skin: 0xf1c27d, partyCol: 0xff4fa3 }),
  human({ shirt: 0xe67e22, pants: 0x2b2f3a, hair: 0x2a1a10, hairStyle: 'long', skin: 0xc68a5a, partyCol: 0x34c3ff }),
  human({ shirt: 0x1abc9c, pants: 0x34302c, hair: 0x4a2e1a, hairStyle: 'slick', skin: 0xf6d0b0, partyCol: 0xffe14a }),
  human({ shirt: 0xff6fa8, pants: 0x3b5b8a, hair: 0x15151a, hairStyle: 'messy', skin: 0x8d5a3a, partyCol: 0x6ee06e }),
  human({ shirt: 0x95a5a6, pants: 0x2b2f3a, hair: 0xb04a2a, hairStyle: 'bun', skin: 0xf1c27d, partyCol: 0xff4fa3 }),
  human({ shirt: 0x34495e, pants: 0x4a3a2a, hair: 0xd9a441, hairStyle: 'long', skin: 0xf6d0b0, partyCol: 0xffb030 }),
];
const dwayne = makeRock(0.3);
const drg = makeDragon(), grf = makeGriffin(), bot = makeRobot();
const cat = makeCritter('cat'), owl = makeCritter('owl'), fox = makeCritter('fox'), bun = makeCritter('bunny'), ham = makeCritter('hamster');
ACT.forEach(a => scene.add(a.root));
PROPS.forEach(p => scene.add(p));

// ---------- helpers ----------
function put(a, x, y, z, ry = 0, s = 1) { const o = a.root || a; o.visible = true; o.position.set(x, y, z); o.rotation.set(0, ry, 0); o.scale.setScalar(s); return a; }
function attach(a, parent, x = 0, y = 0, z = 0) { const o = a.root || a; parent.add(o); o.visible = true; o.position.set(x, y, z); return a; }
const wp = o => { scene.updateMatrixWorld(true); return o.getWorldPosition(new V3()); };
function boxOf(list) { scene.updateMatrixWorld(true); const b = new THREE.Box3(); list.forEach(o => b.expandByObject(o.root || o)); return b; }
function headBox(r) { scene.updateMatrixWorld(true); return new THREE.Box3().expandByObject(r.head); }
function ptsBox(pts, pad = 0) { const b = new THREE.Box3(); pts.forEach(p => b.expandByPoint(Array.isArray(p) ? new V3(...p) : p)); return b.expandByScalar(pad); }
const SAFE = { x: 0.86, top: 0.86, bot: -0.31 }, SHIFT = (SAFE.top + SAFE.bot) / 2, HALFY = (SAFE.top - SAFE.bot) / 2;
function setProj(fov) { camera.fov = fov; camera.aspect = W / H; camera.updateProjectionMatrix(); camera.projectionMatrix.elements[9] = -SHIFT; camera.projectionMatrixInverse.copy(camera.projectionMatrix).invert(); }
function basis(f, roll) { let up = new V3(0, 1, 0); if (Math.abs(f.y) > 0.995) up.set(0, 0, -1); const r = new V3().crossVectors(f, up).normalize(); const u = new V3().crossVectors(r, f).normalize(); if (roll) { r.applyAxisAngle(f, roll); u.applyAxisAngle(f, roll); } return { r, u }; }
const MIN_CAM_Y = 0.35;
function fit(box, opts = {}) {
  // keep the camera above the ground: ease a low angle toward level until it fits
  let o = { ...opts }, r;
  for (let i = 0; i < 40; i++) { r = fit0(box, o); if (r.pos.y >= MIN_CAM_Y || (o.pitch ?? 0.1) >= 0.02) break; o.pitch = (o.pitch ?? 0.1) * 0.88 + 0.004; }
  if (r.pos.y < MIN_CAM_Y) r.pos.y = MIN_CAM_Y;
  return r;
}
function fit0(box, { yaw = 0, pitch = 0.1, zoom = 1, fov = 35, roll = 0 } = {}) {
  const c = box.getCenter(new V3()); const dir = new V3(Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch)); const f = dir.clone().negate(); const { r, u } = basis(f, roll);
  const cs = []; for (const x of [box.min.x, box.max.x]) for (const y of [box.min.y, box.max.y]) for (const z of [box.min.z, box.max.z]) cs.push(new V3(x, y, z));
  const ty = Math.tan(fov * PI / 360), tx = ty * W / H;
  const ok = d => { const cp = c.clone().addScaledVector(dir, d); for (const p of cs) { const v = p.clone().sub(cp); const z = v.dot(f); if (z < 0.05) return false; if (Math.abs(v.dot(r) / (z * tx)) > SAFE.x || Math.abs(v.dot(u) / (z * ty)) > HALFY) return false; } return true; };
  let lo = 0.05, hi = 600; for (let i = 0; i < 50; i++) { const m = (lo + hi) / 2; ok(m) ? hi = m : lo = m; }
  return { pos: c.clone().addScaledVector(dir, hi * Math.max(1, zoom)), look: c, up: u, fov };
}
function cam(pos, look, fov = 40, roll = 0) { const p = new V3(...pos), l = new V3(...look); const { u } = basis(l.clone().sub(p).normalize(), roll); return { pos: p, look: l, up: u, fov }; }
function applyCam(c) { camera.position.copy(c.pos); camera.up.copy(c.up); camera.lookAt(c.look); setProj(c.fov); }
function proj(p) { const v = p.clone().project(camera); return [(v.x + 1) / 2 * W, (1 - v.y) / 2 * H]; }

// ---------- overlay ----------
function caption(t) {
  let ci = -1; for (let i = 0; i < CHUNKS.length; i++) if (CHUNKS[i][0] <= t + 0.02) ci = i; if (ci < 0) return;
  const [c0, c1, idx] = CHUNKS[ci]; if (t > c1 + 0.6 && (ci + 1 >= CHUNKS.length || CHUNKS[ci + 1][0] > t + 0.6)) return;
  const words = idx.map(i => WORDS[i]); let act = 0; words.forEach((w, i) => { if (w[0] <= t) act = i; });
  let px = 62; const g = octx; const meas = () => { g.font = `900 ${px}px ThaiB, InterB, Arial Black, sans-serif`; return words.map(w => g.measureText(w[2].toUpperCase()).width); };
  let ws = meas(), gap = 34, tot = ws.reduce((a, b) => a + b, 0) + gap * (ws.length - 1); while (tot > W - 70) { px -= 4; ws = meas(); tot = ws.reduce((a, b) => a + b, 0) + gap * (ws.length - 1); }
  let x = (W - tot) / 2; const y = 930; g.textBaseline = 'middle'; g.lineJoin = 'round';
  words.forEach((w, i) => { const s = i === act ? 1.08 : 1; g.save(); g.translate(x + ws[i] / 2, y); g.scale(s, s); g.textAlign = 'center'; g.lineWidth = 16; g.strokeStyle = '#121218'; g.strokeText(w[2].toUpperCase(), 0, 0); g.fillStyle = i === act ? (w[3] === 'C' ? '#3fe0ff' : '#ffd21f') : '#ffffff'; g.fillText(w[2].toUpperCase(), 0, 0); g.restore(); x += ws[i] + gap; });
}
function vignette() { const g = octx, gr = g.createRadialGradient(W / 2, H * 0.45, H * 0.3, W / 2, H * 0.45, H * 0.75); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,0.32)'); g.fillStyle = gr; g.fillRect(0, 0, W, H); }
function speed(cx = W / 2, cy = H * 0.4, n = 46, col = 'rgba(255,255,255,0.55)') { const g = octx; g.strokeStyle = col; for (let i = 0; i < n; i++) { const a = hash(i + 200) * 2 * PI, r0 = 260 + hash(i + 300) * 200, r1 = r0 + 160 + hash(i + 400) * 260; g.lineWidth = 2 + hash(i + 500) * 4; g.beginPath(); g.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); g.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1); g.stroke(); } }
function confetti(seed = 0) { const g = octx, cols = ['#ff4fa3', '#ffd21f', '#34c3ff', '#6ee06e', '#ff8a30']; for (let i = 0; i < 90; i++) { g.save(); g.translate(hash(i + seed) * W, hash(i + seed + 50) * H * 0.62); g.rotate(hash(i + seed + 99) * 6); g.fillStyle = cols[i % 5]; g.fillRect(-7, -4, 14, 8); g.restore(); } }
function impact(text, x, y, size, fill, rot = -0.08) { const g = octx; g.save(); g.translate(x, y); g.rotate(rot); g.font = `900 ${size}px ThaiB, InterB, Arial Black, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round'; g.lineWidth = size * 0.22; g.strokeStyle = '#121218'; g.strokeText(text, 0, 0); g.fillStyle = fill; g.fillText(text, 0, 0); g.restore(); }
function flash(a, col = '255,250,230') { octx.fillStyle = `rgba(${col},${a})`; octx.fillRect(0, 0, W, H); }
function shakeLines() { const g = octx; g.strokeStyle = 'rgba(255,255,255,0.7)'; g.lineWidth = 5; g.lineCap = 'round'; for (let i = 0; i < 10; i++) { const x = 60 + hash(i + 900) * (W - 120), y = 520 + hash(i + 901) * 300; g.beginPath(); g.moveTo(x - 18, y); g.lineTo(x - 6, y - 8); g.lineTo(x + 6, y + 8); g.lineTo(x + 18, y); g.stroke(); } }
function clockBlur(p) { const [x, y] = proj(p); const g = octx; g.strokeStyle = 'rgba(255,255,255,0.85)'; g.lineWidth = 6; for (let i = 0; i < 3; i++) { g.beginPath(); g.arc(x, y, 34 + i * 12, -0.4 + i, 1.4 + i); g.stroke(); } }

// ---------- reset ----------
function reset() {
  upgradeTown();
  ACT.forEach(a => { scene.add(a.root); a.root.visible = false; a.root.position.set(0, 0, 0); a.root.rotation.set(0, 0, 0); a.root.scale.setScalar(1); a.pose && a.pose(); if (a.kind === 'human') { a.face({}); a.party.visible = false; } if (a.kind === 'rock') a.face(); if (a.face && a.kind !== 'human' && a.kind !== 'rock') a.face({ eyes: 'normal', mouth: 'smile' }); });
  PROPS.forEach(p => { scene.add(p); p.visible = false; p.position.set(0, 0, 0); p.rotation.set(0, 0, 0); p.scale.setScalar(1); });
  gift.userData.lid.visible = true; gift.userData.glow.visible = false;
  banner.visible = true; race.visible = false; fountain.visible = true; drops.visible = true; ped.visible = false; statue.visible = false; drape.visible = false; rim.intensity = 0;
  drops.children.forEach((d, i) => d.position.y = 2.6 + hash(i + 3) * 0.6); drawClock(9, 0); mood('day');
}

