#!/bin/bash
# bash build.sh        -> quality sheet: board/sheet.jpg + full-res stills/ (a few minutes)
# bash build.sh full   -> full video final.mp4
# NOFX=1 bash build.sh -> fallback without post-processing (if the FX pipeline errors)
set -e
FONT=$(ls node_modules/@fontsource/noto-sans-thai/files/*-thai-900-normal.woff2 2>/dev/null | head -1); [ -n "$FONT" ] && cp "$FONT" thai.woff2 || true
cat engine.js doodle.js helpers.js shots.js > film.js
rm -rf parts board stills
node film-render.js board
node film-render.js still 0.9 2.6 4.2
if [ "$1" = "full" ]; then WORKERS=${WORKERS:-2} node film-render.js all; fi
echo "DONE: see board/sheet.jpg and stills/"
