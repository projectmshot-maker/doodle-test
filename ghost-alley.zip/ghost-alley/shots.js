// ===== "ซอยมืด" — Thai horror short, ~67s, 25 shots, SFX only (voice added later) =====
const girl = doodle({ name: 'girl', skin: 0xffe2c4, shirt: 0xf4f4f4, skirt: { col: 0x1c2650, len: 0.34, r0: 0.3, r1: 0.46 }, hair: 0x14100e, bag: 0xc0392b, shoe: 0xf0f0f0 });
const ghost = doodle({ name: 'ghost', skin: 0xe6ebee, shirt: 0xeef0f2, skirt: { col: 0xeef0f2, len: 0.95, r0: 0.3, r1: 0.55 }, hair: 0x07070a, hairSides: true, hand: 0xe6ebee, shoe: 0xe6ebee });
const phone = M(RB(0.1, 0.2, 0.03, 0.02), 0x15161c, 0.01); girl.hands[1].add(phone);

// ---------- sets ----------
const RX = 40;                      // room is built at x = 40
const alley = new THREE.Group(), room = new THREE.Group();
const lamps = [], bulbs = [];
const doorL = new THREE.PointLight(0xffb060, 0, 7, 2); doorL.position.set(1.0, 1.6, -31); scene.add(doorL);
const bulbL = new THREE.PointLight(0xffd59a, 0, 10, 2); bulbL.position.set(RX, 2.6, 0.2); scene.add(bulbL);
const adoor = new THREE.Group(), rdoor = new THREE.Group();
let roomBulb;
{
  const add = (g, m, x, y, z) => { m.position.set(x, y, z); g.add(m); return m; };
  const A = (m, x, y, z) => add(alley, m, x, y, z);
  A(M(RB(3.6, 0.2, 46, 0.04), 0x2c2f3a, 0), 0, -0.09, -15);                         // floor
  const lw = M(new THREE.PlaneGeometry(46, 5.2), 0x8a8f9a, 0); lw.rotation.y = PI / 2; A(lw, -1.7, 2.6, -15);   // school wall (faces +x)
  const rw = M(new THREE.PlaneGeometry(46, 5.2), 0x5c4b45, 0); rw.rotation.y = -PI / 2; A(rw, 1.7, 2.6, -15);  // old building (faces -x)
  A(M(new THREE.PlaneGeometry(3.4, 5.2), 0x4a4540, 0), 0, 2.6, -37);                // dead end
  for (let i = 0; i < 8; i++) {
    const z = -1 - i * 4.6;
    const w = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 1.0), basic(i % 4 === 2 ? 0x6e5a2a : 0x0a0d18)); w.position.set(1.69, 2.6, z); w.rotation.y = -PI / 2; alley.add(w);
    const w2 = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 1.1), basic(0x0c1220)); w2.position.set(-1.69, 2.4, z - 1.3); w2.rotation.y = PI / 2; alley.add(w2);
  }
  [[-8, 1.2], [-17, 1.1], [-26, 1.3]].forEach(([z, x]) => { A(M(RB(0.6, 0.6, 0.6, 0.06), 0x3a3c44, 0.02), -x + 0.2, 0.3, z); A(M(new THREE.CylinderGeometry(0.25, 0.22, 0.8, 12), 0x2e4a38, 0.02), x - 0.2, 0.4, z + 1.5); });
  [-3, -12, -21, -30].forEach((z, i) => {
    A(M(new THREE.CylinderGeometry(0.05, 0.06, 3.5, 8), 0x1c1e24, 0), 1.55, 1.75, z);
    A(M(RB(0.8, 0.07, 0.07, 0.02), 0x1c1e24, 0), 1.2, 3.5, z);
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 10), basic(0xfff0c0)); b.position.set(0.85, 3.4, z); alley.add(b); bulbs.push(b);
    const L = new THREE.PointLight(0xffe2a0, 0, 12, 2); L.position.set(0.85, 3.3, z); scene.add(L); lamps.push(L);
  });
  adoor.position.set(1.62, 0, -31.5); const dp = M(RB(0.1, 2.2, 1.0, 0.02), 0x7b4a2b, 0.02); dp.position.set(0, 1.1, 0.5); adoor.add(dp); alley.add(adoor);
  const gl = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 2.2), basic(0xffb55a)); gl.position.set(1.695, 1.1, -31); gl.rotation.y = -PI / 2; alley.add(gl);
  // ---- room ----
  const R = (m, x, y, z) => add(room, m, x, y, z);
  R(M(RB(4.6, 0.2, 4.6, 0.03), 0x5a3f2b, 0), RX, -0.09, 0);
  const wl = (c, ry, x, z) => { const w = M(new THREE.PlaneGeometry(4.4, 3.1), c, 0); w.rotation.y = ry; R(w, x, 1.55, z); };
  wl(0x6c7068, 0, RX, -2.2); wl(0x6c7068, PI, RX, 2.2); wl(0x646860, PI / 2, RX - 2.2, 0); wl(0x646860, -PI / 2, RX + 2.2, 0);
  const ce = M(new THREE.PlaneGeometry(4.4, 4.4), 0x4a4c48, 0); ce.rotation.x = PI / 2; R(ce, RX, 3.1, 0);
  rdoor.position.set(RX, 0, -2.15); room.add(rdoor);
  const pan = M(RB(1.1, 2.25, 0.1, 0.02), 0x7b4a2b, 0.02); pan.position.y = 1.125; rdoor.add(pan);
  const hnd = M(SPH(0.05, 10), 0xcdbb6a, 0.01); hnd.position.set(0.4, 1.05, 0.09); rdoor.add(hnd);
  R(M(RB(0.7, 0.7, 0.7, 0.04), 0x8a6a3a, 0.02), RX + 1.7, 0.35, -1.6); R(M(RB(0.5, 0.4, 0.5, 0.04), 0x9a7a44, 0.02), RX + 1.7, 0.9, -1.6);
  R(M(RB(0.4, 1.8, 1.6, 0.03), 0x4a3a2a, 0.02), RX - 1.95, 0.9, 0.3);
  for (let i = 0; i < 4; i++) R(M(new THREE.CylinderGeometry(0.07, 0.07, 0.2, 10), 0x7aa088, 0.01), RX - 1.7, 1.0 + (i % 2) * 0.5, -0.2 + i * 0.35);
  const win = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 1.1), basic(0x16264a)); win.position.set(RX - 2.19, 1.9, -0.9); win.rotation.y = PI / 2; room.add(win);
  roomBulb = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), basic(0xffe6b0)); roomBulb.position.set(RX, 2.62, 0.2); room.add(roomBulb);
  R(M(new THREE.CylinderGeometry(0.01, 0.01, 0.5, 4), 0x111111, 0), RX, 2.88, 0.2);
}
scene.add(alley); scene.add(room); PROPS.push(alley, room);
ACT.forEach(a => scene.add(a.root));

// ---------- helpers ----------
const Z = (a, b, k) => a + (b - a) * k;
const lerp3 = (a, b, k) => a.map((v, i) => v + (b[i] - v) * k);
const cam3 = (p, l, fov = 38, roll = 0) => { const pos = new V3(...p), look = new V3(...l); look.y -= SHIFT * pos.distanceTo(look) * Math.tan(fov * PI / 360); return { pos, look, up: new V3(Math.sin(roll), Math.cos(roll), 0), fov }; };
const dolly = (pa, pb, la, lb, k, fov, ra = 0, rb = 0) => { const q = ss(k); return cam3(lerp3(pa, pb, q), lerp3(la, lb, q), fov, ra + (rb - ra) * q); };
const lerpBox = (a, b, k) => new THREE.Box3(a.min.clone().lerp(b.min, k), a.max.clone().lerp(b.max, k));
const upper = r => { const b = headBox(r); b.min.y -= 0.9; return b.expandByScalar(0.08); };
const fl = (t, rate = 18, th = 0.45) => hash(Math.floor(t * rate) + 7) > th ? 1 : 0.08;
const follow = (x, y, z, i = 4.5, col = 0x9fb4ff) => { rim.color.set(col); rim.position.set(x, y, z); rim.intensity = i; rim.distance = 14; };
function env(mode, o = {}) {
  town.visible = false; sky.visible = false; fountain.visible = false; drops.visible = false; banner.visible = false;
  scene.background = new THREE.Color(0x03040a); renderer.toneMappingExposure = 1.15;
  const al = mode === 'alley';
  hemi.color.set(0x28365a); hemi.groundColor.set(0x0a0b12); hemi.intensity = al ? 0.55 : 0.16;
  sun.color.set(0x5a78c8); sun.intensity = al ? 0.35 : 0; sun.position.set((o.cx ?? 0) + 6, 18, (o.cz ?? 0) + 8); sun.target.position.set(o.cx ?? 0, 0, o.cz ?? 0);
  scene.fog = new THREE.FogExp2(0x03040a, al ? 0.04 : 0.02);
  alley.visible = al; room.visible = !al; phone.visible = !al; rdoor.visible = true;
  const fk = o.flick || [1, 1, 1, 1];
  lamps.forEach((L, i) => { L.intensity = al ? 12 * fk[i] : 0; bulbs[i].material.color.set(fk[i] > 0.3 ? 0xfff0c0 : 0x2a2a22); });
  doorL.intensity = al ? 6 : 0;
  const bu = o.bulb ?? 1; bulbL.intensity = al ? 0 : 10 * bu; roomBulb.material.color.set(bu > 0.3 ? 0xffe6b0 : 0x2a2a22);
  rim.intensity = 0;
}
function gWalk(z, x, ph, amp = 0.7, extra = {}) {
  put(girl, x, 0, z, PI);
  girl.pose({ lL: Math.sin(ph) * amp, lR: -Math.sin(ph) * amp, kL: Math.max(0, -Math.sin(ph)) * amp, kR: Math.max(0, Math.sin(ph)) * amp, aLx: -Math.sin(ph) * amp * 0.7, aRx: Math.sin(ph) * amp * 0.7, y: Math.abs(Math.cos(ph)) * 0.04 * amp, ...extra });
}
const gRun = (z, x, t, extra = {}) => gWalk(z, x, t * 11, 1.25, { tx: 0.22, y: Math.abs(Math.cos(t * 11)) * 0.1, ...extra });
const KN = [54.0, 54.55, 55.1, 55.9, 56.3, 56.7, 57.3, 57.6];
const knock = t => KN.reduce((m, k) => Math.max(m, t >= k ? Math.exp(-(t - k) * 14) : 0), 0);
function roomGirl(extra = {}) { put(girl, RX, 0, -1.6, PI); girl.pose({ tx: 0.25, aLx: -1.5, aRx: -1.5, aLz: 0.1, aRz: 0.1, ...extra }); }

// ---------- shots ----------
const S = []; let tt = 0;
const shot = (dur, fn) => { S.push({ t0: tt, t1: tt + dur, fn }); tt += dur; };

shot(3.0, (u, t, k) => { env('alley', { cz: -3, flick: [fl(t, 16, 0.4), 1, 1, 1] }); return { cam: dolly([0, 1.5, 3.8], [0, 1.45, -1.2], [0, 1.6, -9], [0, 1.6, -10], k, 42) }; });
shot(2.8, (u, t, k) => { env('alley', { cz: 0 }); const z = Z(1.5, -1.2, k); gWalk(z, 0.1, t * 5.2); follow(0.5, 2.4, z + 2.2); girl.face({ eyes: 'sleepy', brow: 'flat', mouth: 'flat' }); return { cam: mv(boxOf([girl]), k, { yaw: 0.3, pitch: 0.14, zoom: 1.3, fov: 34 }, { yaw: -0.1, pitch: 0.1, zoom: 1.3 }, 1) }; });
shot(2.6, (u, t, k) => { env('alley', { cz: -3 }); const z = Z(-2, -4.6, k); gWalk(z, 0, t * 5.2); follow(-1.0, 2.2, z + 0.8); girl.face({ eyes: 'sleepy', brow: 'sad', mouth: 'flat' }); return { cam: mv(boxOf([girl]), k, { yaw: 1.3, pitch: 0.08, zoom: 1.15, fov: 34 }, { yaw: 1.1, pitch: 0.1, zoom: 1.15 }, 1) }; });
shot(3.1, (u, t, k) => { env('alley', { cz: -6 }); const z = Z(-5, -8, k); gWalk(z, 0, t * 5.2); follow(0.4, 2.6, z + 0.8, 5); girl.face({ eyes: 'dot', brow: 'flat', mouth: 'flat' }); return { cam: mv(ptsBox([[-1.6, 0, z + 3.5], [1.6, 0.5, z - 3.5]]), k, { yaw: 0.2, pitch: 1.2, zoom: 1, fov: 38 }, { yaw: -0.2, pitch: 1.1 }) }; });
shot(3.0, (u, t, k) => { env('alley', { cz: -10 }); const z = Z(-9, -11.4, k); gWalk(z, 0, t * 5.2); follow(0.3, 2.4, z - 1.5); girl.face({ eyes: 'dot', brow: 'sad', mouth: 'flat', lx: -0.3 }); return { cam: mv(boxOf([girl]), k, { yaw: PI + 0.2, pitch: 0.08, zoom: 1.35, fov: 34 }, { yaw: PI - 0.1, pitch: 0.08, zoom: 1.35 }, 1) }; });
shot(3.0, (u, t, k) => { const f1 = fl(t, 22, 0.5); env('alley', { cz: -12, flick: [1, f1, 1, 1] }); const z = Z(-9.8, -13.8, k); gWalk(z, 0, t * 5.2); follow(-0.4, 2.2, z + 1.2, 3); girl.face({ eyes: 'dot', brow: 'sad', mouth: 'flat' }); return { cam: dolly([-0.6, 1.9, -8.3], [-0.2, 2.1, -8.9], [0.9, 3.2, -12], [0.8, 3.0, -12], k, 40) }; });
shot(3.0, (u, t, k) => { env('alley', { cz: -18 }); const z = Z(-16.8, -19.2, k); gWalk(z, 0, t * 5.2); follow(-1.0, 2.0, z + 1, 4); girl.face({ eyes: 'dot', mouth: 'flat' }); return { cam: mv(ptsBox([[-0.55, 0, z + 0.5], [0.55, 0.75, z - 0.5]]), k, { yaw: 1.25, pitch: 0.04, zoom: 1, fov: 32 }, { yaw: 1.0, pitch: 0.05 }, 1) }; });
shot(3.0, (u, t, k) => { env('alley', { cz: -21 }); const z = Z(-20.5, -22.2, k); const mvg = k < 0.55 ? 1 - k / 0.55 : 0; gWalk(z, 0, t * 5.2 * mvg + 1, 0.6 * mvg + 0.001, { hy: -0.6 * ss(Math.max(0, (k - 0.5) * 2)) }); follow(0.3, 2.4, z + 2.4); girl.face({ eyes: 'dot', mouth: 'flat' }); return { cam: mv(boxOf([girl]), k, { yaw: 0.1, pitch: 0.15, zoom: 1.15, fov: 34 }, { yaw: 0.25, pitch: 0.1, zoom: 1.15 }, 1) }; });
shot(2.5, (u, t, k) => { env('alley', { cz: -22 }); put(girl, 0, 0, -22.2, PI); girl.pose({ hy: -0.5, hz: 0.06 }); follow(0.2, 2.2, -20.6, 5); girl.face({ eyes: 'wide', brow: 'sad', mouth: 'o', sweat: true, lx: Math.sin(t * 7) * 0.6 }); return { cam: mv(upper(girl), k, { yaw: PI + 0.45, pitch: 0.02, zoom: 1, fov: 30 }, { yaw: PI + 0.2, pitch: 0.02 }, 1.5) }; });
shot(2.5, (u, t, k) => { env('alley', { cz: -15, flick: [1, k > 0.7 ? fl(t, 20, 0.5) : 1, 1, 1] }); return { cam: dolly([0.5, 1.45, -21.0], [0.4, 1.45, -19.4], [0, 1.55, -6], [0, 1.55, -7], k, 44, 0.05, -0.03) }; });
shot(2.5, (u, t, k) => { env('alley', { cz: -25 }); const z = Z(-22.6, -27.4, k); gWalk(z, 0, t * 7.8, 0.95, { hy: -0.2 }); follow(1.0, 2.2, z + 0.8); girl.face({ eyes: 'wide', brow: 'sad', mouth: 'o', sweat: true }); return { cam: mv(boxOf([girl]), k, { yaw: -1.25, pitch: 0.1, zoom: 1.35, fov: 36 }, { yaw: -1.05, pitch: 0.1, zoom: 1.35 }, 1.5) }; });
shot(2.5, (u, t, k) => { env('alley', { cz: -27 }); const z = Z(-27.4, -28.6, k); gWalk(z, 0, t * 7.8, 0.9); follow(0.3, 2.2, z - 1.6, 5); girl.face({ eyes: 'wide', brow: 'sad', mouth: 'wavy', sweat: true, lx: Math.sin(t * 9) }); return { cam: mv(upper(girl), k, { yaw: PI - 0.35, pitch: 0.0, zoom: 1, fov: 30 }, { yaw: PI - 0.1, pitch: 0.0 }, 2) }; });
shot(2.0, (u, t, k) => { env('alley', { cz: -28 }); const z = -28.8; const hy = k < 0.5 ? -0.6 * ss(k * 2) : -0.6 * ss((1 - k) * 2); gWalk(z, 0, t * 5, 0.2, { hy, aLx: -0.6, aRx: -0.5 }); follow(0.4, 2.2, z + 2, 4); girl.face({ eyes: 'wide', mouth: 'wavy' }); return { cam: mv(upper(girl), k, { yaw: 0.35, pitch: 0.25, zoom: 1, fov: 30 }, { yaw: 0.2, pitch: 0.2 }, 1.5) }; });
shot(2.0, (u, t, k) => { env('alley', { cz: -11 }); const z = Z(-9, -14, k); gRun(z, 0, t); follow(0.3, 2.4, z + 2); girl.face({ eyes: 'wide', mouth: 'o' }); return { cam: mv(ptsBox([[-0.9, 0, z + 0.8], [0.9, 1.3, z - 1.2]]), k, { yaw: 0.15, pitch: 0.03, zoom: 1, fov: 36 }, { yaw: 0.0, pitch: 0.05 }, 2.5) }; });
shot(2.5, (u, t, k) => { env('alley', { cz: -17 }); const z = Z(-14, -20, k); gRun(z, 0, t); follow(0.3, 2.4, z - 1.8, 5); girl.face({ eyes: 'wide', brow: 'sad', mouth: 'o', tear: true, sweat: true }); return { cam: mv(boxOf([girl]), k, { yaw: PI - 0.15, pitch: 0.06, zoom: 1.5, fov: 36 }, { yaw: PI + 0.15, pitch: 0.06, zoom: 1.4 }, 3), fx: () => speed(W / 2, H * 0.42, 40) }; });
shot(2.5, (u, t, k) => { env('alley', { cz: -23 }); const z = Z(-20, -26, k); gRun(z, 0, t); follow(-1.0, 2.2, z + 1); girl.face({ eyes: 'wide', brow: 'sad', mouth: 'o', tear: true }); return { cam: mv(boxOf([girl]), k, { yaw: 1.35, pitch: 0.08, zoom: 1.2, fov: 36 }, { yaw: 1.2, pitch: 0.08, zoom: 1.2 }, 2.5) }; });
shot(2.5, (u, t, k) => { const z = Z(-26.2, -30.2, k); env('alley', { cz: -28 }); gRun(z, 0.4, t); follow(0.2, 2.4, z + 2.6, 5); girl.face({ eyes: 'wide', mouth: 'o', tear: true }); return { cam: cam3([0.1, 1.6, z + 2.8], [0.9, 1.3, z - 4], 40, 0) }; });
shot(2.4, (u, t, k) => {
  env('alley', { cz: -31 }); const o = ss(Math.max(0, Math.min(1, (k - 0.08) / 0.3))), c = ss(Math.max(0, (k - 0.85) / 0.12)); adoor.rotation.y = -1.35 * o * (1 - c);
  if (k < 0.3) gRun(Z(-28.8, -31, k / 0.3), 0.3, t); else { const q = ss((k - 0.3) / 0.25); put(girl, Z(0.3, 2.3, q), 0, -31, PI - (PI / 2) * q); girl.pose({ lL: Math.sin(t * 11) * 1.1, lR: -Math.sin(t * 11) * 1.1, tx: 0.2 }); }
  follow(0.0, 2.4, -29.5, 5); girl.face({ eyes: 'wide', mouth: 'o', tear: true });
  return { cam: mv(ptsBox([[0.0, 0, -33], [1.8, 2.6, -29.5]]), k, { yaw: -1.15, pitch: 0.08, zoom: 1, fov: 34 }, { yaw: -1.0, pitch: 0.08 }, 1.5) };
});
shot(2.6, (u, t, k) => {
  env('room', { bulb: 0.4 + 0.6 * fl(t, 14, 0.4) }); const o = Math.max(0, 1 - u / 0.12); rdoor.rotation.y = -1.2 * o; roomGirl({ hz: 0.05 });
  follow(RX + 1.2, 2.2, 0.2, 3, 0xffd59a); girl.face({ eyes: 'wide', brow: 'sad', mouth: 'o', tear: true });
  return { cam: mv(ptsBox([[RX - 1.3, 0, -2.3], [RX + 1.3, 2.6, -0.5]]), k, { yaw: 0.15, pitch: 0.1, zoom: 1, fov: 40 }, { yaw: -0.1, pitch: 0.08 }, 1.5), fx: () => { if (u < 0.12) flash(0.5 * (1 - u / 0.12)); if (u > 0.1 && u < 0.9) impact('ปัง!', W / 2, H * 0.28, 120, '#ffd21f'); } };
});
shot(2.8, (u, t, k) => {
  env('room', { bulb: 0.5 + 0.5 * fl(t, 9, 0.3) }); roomGirl({ hy: -1.1, ty: -0.5, aRx: -2.7, aRz: 1.0 }); follow(RX + 1.6, 1.8, -0.6, 4, 0xffd59a);
  girl.face({ eyes: 'closed', brow: 'sad', mouth: 'wavy', tear: true }); return { cam: mv(upper(girl), k, { yaw: 1.1, pitch: 0.05, zoom: 1, fov: 30 }, { yaw: 1.3, pitch: 0.05 }, 2) };
});
shot(2.2, (u, t, k) => {
  env('room', { bulb: 0.6 + 0.4 * fl(t, 9, 0.3) }); const kn = knock(t); rdoor.position.z = -2.15 + kn * 0.03 * Math.sin(t * 90); rdoor.rotation.z = kn * 0.01 * Math.sin(t * 70);
  roomGirl({ aRx: -2.7, aRz: 1.0, hz: kn * 0.05 }); follow(RX + 0.6, 2.2, 0.4, 3, 0xffd59a); girl.face({ eyes: 'wide', brow: 'sad', mouth: 'wavy', tear: true });
  return { cam: mv(ptsBox([[RX - 1.6, 0, -2.3], [RX + 1.6, 2.8, 1.5]]), k, { yaw: 0.55, pitch: 0.12, zoom: 1, fov: 40 }, { yaw: 0.35, pitch: 0.12 }, 1.5), fx: () => { if (kn > 0.6) shakeLines(); } };
});
shot(2.5, (u, t, k) => {
  env('room', { bulb: 0.6 + 0.4 * fl(t, 9, 0.3) }); const kn = knock(t); rdoor.position.z = -2.15 + kn * 0.04 * Math.sin(t * 90); rdoor.rotation.z = kn * 0.012 * Math.sin(t * 70);
  roomGirl({ aRx: -2.7, aRz: 1.0, hz: kn * 0.05 }); follow(RX + 0.5, 2.2, 0.0, 4, 0xffd59a); girl.face({ eyes: 'wide', brow: 'sad', mouth: 'wavy', tear: true });
  return { cam: mv(ptsBox([[RX - 0.9, 0.4, -2.3], [RX + 0.9, 2.2, -1.2]]), k, { yaw: 0.15, pitch: 0.05, zoom: 1, fov: 34 }, { yaw: 0.05, pitch: 0.05 }, 2.5), fx: () => { if (kn > 0.6) shakeLines(); } };
});
shot(2.5, (u, t, k) => {
  env('room', { bulb: 0.5 * (1 - 0.4 * k) * fl(t, 8, 0.2) + 0.15 }); roomGirl({ hy: 1.1, ty: 0.5, aRx: -2.7, aRz: 1.0 }); follow(RX - 1.6, 1.8, -0.6, 3, 0xffd59a);
  girl.face({ eyes: 'wide', brow: 'sad', mouth: 'o', sweat: true, tear: true, lx: 0, ly: 0.3 }); return { cam: mv(upper(girl), k, { yaw: -1.1, pitch: 0.05, zoom: 1, fov: 30 }, { yaw: -1.25, pitch: 0.05 }, 1.5) };
});
shot(3.8, (u, t, k) => {
  const dark = k > 0.42 && k < 0.52; env('room', { bulb: dark ? 0 : 0.35 + 0.15 * fl(t, 10, 0.3) }); rdoor.visible = k < 0.45;
  roomGirl({ aRx: -2.7, aRz: 1.0 }); girl.face({ eyes: 'wide', brow: 'sad', mouth: 'o', tear: true, sweat: true });
  if (k > 0.5) { put(ghost, RX + 0.15, 0.08, -0.15, PI); ghost.pose({ hz: 0.18, aLx: -0.3, aRx: -0.2 }); ghost.face({ eyes: 'void', mouth: 'grin' }); }
  follow(RX, 1.9, -0.6, dark ? 0 : 3, 0xbfd0ff);
  return { cam: mv(ptsBox([[RX - 0.7, 0, -2.0], [RX + 0.7, 2.25, 0.3]]), k, { yaw: 1.15, pitch: 0.08, zoom: 1, fov: 38 }, { yaw: PI, pitch: 0.05 }, 1) };
});
shot(3.6, (u, t, k) => {
  env('room', { bulb: 0.3 + 0.2 * fl(t, 7, 0.3) }); put(ghost, RX + 0.15, 0.08, -0.15, PI); ghost.pose({ hz: 0.18 + Math.sin(t * 2) * 0.03, aLx: -0.3, aRx: -0.2 }); ghost.face({ eyes: 'void', mouth: 'grin' });
  follow(RX, 1.9, -1.8, 6, 0xcfdcff);
  return { cam: mv(lerpBox(upper(ghost), headBox(ghost).expandByScalar(0.05), ss(k)), 0, { yaw: PI, pitch: 0.0, zoom: 1, fov: 30 }, {}, 0.8), fx: () => { if (u > 3.2) { octx.fillStyle = `rgba(0,0,0,${Math.min(1, (u - 3.2) / 0.3)})`; octx.fillRect(0, 0, W, H); } } };
});

const END = AUDIO_DUR, DUR = Math.round((AUDIO_DUR + 0.5) * 100) / 100;
window.SHOT_COUNT = S.length;
window.SHOTS = S.map(s => [s.t0, s.t1]);
window.DUR = DUR;
function draw(t) {
  T = t; octx.setTransform(1.5, 0, 0, 1.5, 0, 0);
  if (t >= END) { octx.fillStyle = '#000'; octx.fillRect(0, 0, W, H); return; }
  let s = S.find(s => t >= s.t0 && t < s.t1) || S[S.length - 1];
  reset(); const u = t - s.t0, k = cl(u / (s.t1 - s.t0)); const r = s.fn(u, t, k);
  ACT.forEach((a, i) => { if ((a.kind === 'human' || a.kind === 'doodle') && a.root.visible) a.head.rotation.z += Math.sin(t * 1.6 + i) * 0.035; });
  applyCam(r.cam); renderer.render(scene, camera);
  octx.drawImage(renderer.domElement, 0, 0, W, H); vignette(); r.fx && r.fx(); caption(t);
}
window.renderFrame = t => { draw(t); return out.toDataURL('image/jpeg', 0.92); };
window.renderShot = (i, tt2) => { const s = S[i - 1]; return window.renderFrame(tt2 ?? (s.t0 + s.t1) / 2); };
Promise.allSettled([document.fonts.load('900 60px InterB'), document.fonts.load('900 60px ThaiB', 'ก')]).then(() => { window.ready = true; });
