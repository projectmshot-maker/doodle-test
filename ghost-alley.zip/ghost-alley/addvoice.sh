#!/bin/bash
# bash addvoice.sh voice.mp3   -> final_voice.mp4 (voice on top of the SFX already in final.mp4)
ffmpeg -y -i final.mp4 -i "$1" -filter_complex "[0:a]volume=0.55[a];[1:a]volume=1.3[b];[a][b]amix=inputs=2:duration=first:normalize=0[o]" -map 0:v -map "[o]" -c:v copy -c:a aac final_voice.mp4
