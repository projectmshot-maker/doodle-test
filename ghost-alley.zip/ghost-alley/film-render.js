// node film-render.js still <t...>        -> stills/t_<t>.jpg
// node film-render.js board               -> one mid-shot frame per shot -> board/shot_NN.jpg + board/sheet.jpg (storyboard)
// node film-render.js shots               -> start/mid/end of every shot -> checks/
// node film-render.js part <name> <f0> <f1> -> parts/<name>.mp4
// node film-render.js all                 -> final.mp4 (WORKERS parallel, default 2)
const http = require('http'), fs = require('fs'), path = require('path'), { spawn } = require('child_process');
const { chromium } = require('playwright');
const root = __dirname, FPS = 24;
const types = { '.html': 'text/html', '.js': 'text/javascript', '.woff2': 'font/woff2' };
function serve(port) { return http.createServer((q, r) => { const p = path.join(root, decodeURIComponent(q.url.split('?')[0])); fs.readFile(p, (e, d) => { if (e) { r.writeHead(404); r.end(); return; } r.writeHead(200, { 'Content-Type': types[path.extname(p)] || 'application/octet-stream' }); r.end(d); }); }).listen(port); }
async function open(port) {
  const cpu = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'];
  const gpu = ['--ignore-gpu-blocklist', '--enable-gpu', ...(process.platform === 'win32' ? ['--use-angle=d3d11'] : [])];
  let b; try { b = await chromium.launch({ args: process.env.CPU === '1' || process.platform === 'linux' ? cpu : gpu }); } catch (e) { b = await chromium.launch({ args: cpu }); }
  const pg = await b.newPage({ viewport: { width: 1080, height: 1920 } });
  pg.on('pageerror', e => console.log('[err]', e.message));
  await pg.goto(`http://localhost:${port}/film.html`);
  await pg.waitForFunction('window.ready === true', null, { timeout: 180000 });
  return { b, pg };
}
const save = (f, url) => fs.writeFileSync(f, Buffer.from(url.split(',')[1], 'base64'));
(async () => {
  const [mode, ...a] = process.argv.slice(2); const port = 8200 + Math.floor(Math.random() * 700); const srv = serve(port);
  const { b, pg } = await open(port);
  if (mode === 'still') { fs.mkdirSync('stills', { recursive: true }); for (const t of a) save(path.join(root, 'stills', `t_${t}.jpg`), await pg.evaluate(t => window.renderFrame(t), +t)); }
  if (mode === 'board') {
    fs.mkdirSync('board', { recursive: true }); const shots = await pg.evaluate('window.SHOTS');
    for (let i = 0; i < shots.length; i++) { const [t0, t1] = shots[i]; save(path.join(root, 'board', `shot_${String(i + 1).padStart(2, '0')}.jpg`), await pg.evaluate(t => window.renderFrame(t), (t0 + t1) / 2)); }
    const cols = Math.min(11, shots.length);
    await new Promise(r => spawn('ffmpeg', ['-y', '-loglevel', 'error', '-pattern_type', 'glob', '-i', 'board/shot_*.jpg', '-vf', `scale=360:-1,tile=${cols}x${Math.ceil(shots.length / cols)}:padding=6:color=white`, '-frames:v', '1', 'board/sheet.jpg'], { stdio: 'inherit', cwd: root }).on('close', r));
  }
  if (mode === 'shots') {
    fs.mkdirSync('checks', { recursive: true }); const shots = await pg.evaluate('window.SHOTS');
    for (let i = 0; i < shots.length; i++) { const [t0, t1] = shots[i]; for (const [tag, tt] of [['a', t0 + 0.04], ['b', (t0 + t1) / 2], ['c', t1 - 0.05]]) save(path.join(root, 'checks', `s${String(i + 1).padStart(2, '0')}${tag}.jpg`), await pg.evaluate(t => window.renderFrame(t), tt)); }
  }
  if (mode === 'part') {
    const [name, f0, f1] = [a[0], +a[1], +a[2]]; fs.mkdirSync('parts', { recursive: true });
    const tmp = path.join(root, 'parts', name + '.tmp.mp4');
    const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-c:v', 'mjpeg', '-framerate', String(FPS), '-i', '-', '-c:v', 'libx264', '-crf', '18', '-preset', 'veryfast', '-pix_fmt', 'yuv420p', '-r', String(FPS), tmp], { stdio: ['pipe', 'inherit', 'inherit'] });
    const t0 = Date.now();
    for (let f = f0; f < f1; f++) { const url = await pg.evaluate(t => window.renderFrame(t), f / FPS); if (!ff.stdin.write(Buffer.from(url.split(',')[1], 'base64'))) await new Promise(r => ff.stdin.once('drain', r)); if ((f - f0) % 60 === 0) console.log(name, f, ((Date.now() - t0) / 1000 / (f - f0 + 1)).toFixed(2) + 's/f'); }
    ff.stdin.end(); const code = await new Promise(r => ff.on('close', r)); if (code === 0) fs.renameSync(tmp, path.join(root, 'parts', name + '.mp4')); else console.log('ffmpeg failed', code);
  }
  const DUR = await pg.evaluate('window.DUR');
  await b.close(); srv.close();
  if (mode === 'all') {
    const total = Math.round(DUR * FPS), N = 10, W = +(process.env.WORKERS || 2), jobs = [];
    for (let i = 0; i < N; i++) jobs.push([`p${String(i).padStart(2, '0')}`, Math.floor(total * i / N), Math.floor(total * (i + 1) / N)]);
    const todo = jobs.filter(j => !fs.existsSync(path.join(root, 'parts', j[0] + '.mp4')));
    const run = j => new Promise(r => { const p = spawn(process.execPath, [__filename, 'part', ...j.map(String)], { stdio: 'inherit', cwd: root }); p.on('close', r); });
    await Promise.all(Array.from({ length: W }, async () => { while (todo.length) await run(todo.shift()); }));
    fs.writeFileSync(path.join(root, 'parts', 'list.txt'), jobs.map(j => `file '${j[0]}.mp4'`).join('\n'));
    await new Promise(r => spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', 'parts/list.txt', '-i', 'mix.wav', '-map', '0:v', '-map', '1:a', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', 'final.mp4'], { stdio: 'inherit', cwd: root }).on('close', r));
    console.log('done final.mp4');
  }
})();
