#!/bin/bash
# usage:  bash build.sh          -> storyboard only (board/sheet.jpg) ~ 3 min
#         bash build.sh full     -> full render final.mp4 (long)
set -e
python3 sfx.py
FONT=$(ls node_modules/@fontsource/noto-sans-thai/files/*-thai-900-normal.woff2 | head -1); cp "$FONT" thai.woff2
cat engine.js doodle.js helpers.js shots.js > film.js
rm -rf parts board
node film-render.js board
if [ "$1" = "full" ]; then WORKERS=${WORKERS:-2} node film-render.js all; fi
