# sfx.py — procedural horror SFX (stdlib only) -> mix.wav (mono, 24 kHz). No voice: add it later.
import wave, struct, math, random
SR=24000; END=67.4; DUR=END+0.6; N=int(SR*DUR); buf=[0.0]*N; random.seed(7)
def add(t,sig,g=1.0):
    i0=int(t*SR)
    for j,v in enumerate(sig):
        i=i0+j
        if 0<=i<N: buf[i]+=v*g
def noise(n): return [random.uniform(-1,1) for _ in range(n)]
def lp(s,a):
    y=0.0; o=[]
    for x in s: y+=a*(x-y); o.append(y)
    return o
def hp(s,a): return [x-y for x,y in zip(s,lp(s,a))]
def step(a=0.2,dur=0.08,dec=0.02):
    n=int(dur*SR); s=lp(noise(n),a); return [x*math.exp(-i/(dec*SR))*1.6 for i,x in enumerate(s)]
def thump(f0=110,f1=40,dur=0.25,dec=0.07):
    n=int(dur*SR); o=[]; ph=0.0
    for i in range(n):
        f=f1+(f0-f1)*math.exp(-i/(0.04*SR)); ph+=2*math.pi*f/SR; o.append(math.sin(ph)*math.exp(-i/(dec*SR)))
    return o
def knock(): return [a+b for a,b in zip(thump(150,70,0.2,0.05),[x*0.6 for x in step(0.5,0.2,0.012)])]
def boom(): return [a+b*0.8 for a,b in zip(thump(70,26,0.9,0.3),step(0.08,0.9,0.25))]
def buzz(d):
    n=int(d*SR); o=[]
    for i in range(n):
        t=i/SR; gate=1.0 if (int(t*23)%3)!=0 else 0.15; o.append(((2*((100*t)%1)-1)*0.5+random.uniform(-1,1)*0.3)*gate*0.35)
    return o
def beep(f1,f2,d=0.1):
    n=int(d*SR); return [(math.sin(2*math.pi*f1*i/SR)+math.sin(2*math.pi*f2*i/SR))*0.18 for i in range(n)]
def ring(d=0.4):
    n=int(d*SR); return [(math.sin(2*math.pi*440*i/SR)+math.sin(2*math.pi*480*i/SR))*0.14 for i in range(n)]
def breath(d=0.3):
    n=int(d*SR); s=hp(noise(n),0.3); return [x*math.sin(math.pi*i/n)*0.5 for i,x in enumerate(s)]
def rng(a,b,step_):
    t=a
    while t<b: yield t; t+=step_
# ambience: wind + tension drone
wind=lp(noise(N),0.012)
for i in range(N):
    t=i/SR; sw=0.6+0.4*math.sin(t*0.35); drone=math.sin(2*math.pi*55*t)*(0.02+0.06*max(0,min(1,(t-20)/40)))
    buf[i]+=wind[i]*5.0*sw*0.12+drone
# girl footsteps
for i,t in enumerate(rng(3.0,22.0,0.58)): add(t,step(0.2),0.42 if i%2 else 0.5)
for i,t in enumerate(rng(28.5,35.5,0.42)): add(t,step(0.22),0.5)
for i,t in enumerate(rng(35.5,47.0,0.27)): add(t,step(0.25),0.65)
# follower (heavier, lower)
for t in rng(21.4,26.8,0.58): add(t+0.29,step(0.1,0.1,0.03),0.55)
for t in rng(28.7,35.5,0.40): add(t,step(0.1,0.1,0.03),0.62)
for t in rng(35.5,47.0,0.24): add(t+0.1,step(0.1,0.1,0.03),0.8)
# lamp / bulb buzz
for a,b in [(0.9,2.6),(14.6,17.4),(47.6,52.0),(58.0,60.3),(61.0,61.6)]: add(a,buzz(b-a),0.22)
# heartbeat
t=23.2
while t<47.0:
    g=0.25+0.5*min(1,(t-23)/22); add(t,thump(95,45,0.2,0.06),g); add(t+0.16,thump(80,40,0.2,0.05),g*0.7); t+=max(0.45,1.0-(t-23)*0.025)
for t in rng(52.0,54.0,0.9): add(t,thump(95,45,0.2,0.06),0.3); add(t+0.16,thump(80,40,0.2,0.05),0.2)
for t in rng(57.6,62.0,0.62): add(t,thump(95,45,0.2,0.06),0.6); add(t+0.16,thump(80,40,0.2,0.05),0.45)
for t in rng(36.0,46.0,0.5): add(t,breath(0.3),0.12)
# door slam, phone, knocks
add(47.3,boom(),1.0)
for i,t in enumerate(rng(49.6,50.5,0.13)): add(t,beep(697+(i%3)*70,1209+(i%2)*130),0.5)
for t in (51.0,51.6): add(t,ring(0.4),0.5)
for t in [54.0,54.55,55.1,55.9,56.3,56.7,57.3,57.6]: add(t,knock(),1.0)
# silence + rising whine, then reveal sting
for i in range(int(59.0*SR),int(62.0*SR)):
    t=i/SR; buf[i]+=math.sin(2*math.pi*3000*t)*0.012*(t-59.0)/3.0
add(62.0,boom(),1.0)
n=int(1.6*SR)
for j in range(n):
    t=j/SR; i=int(62.0*SR)+j
    if i<N: buf[i]+=(math.sin(2*math.pi*(1800+120*math.sin(t*60))*t)+math.sin(2*math.pi*2600*t)*0.6+random.uniform(-1,1)*0.3)*math.exp(-t*1.8)*0.28
add(63.8,hp(noise(int(3.6*SR)),0.2),0.0)
wh=hp(noise(int(3.4*SR)),0.25)
for j,x in enumerate(wh):
    i=int(64.0*SR)+j
    if i<N: buf[i]+=x*math.sin(math.pi*j/len(wh))*0.05
# hard cut at END
e=int(END*SR)
for i in range(e,N): buf[i]=0.0
for i in range(e-int(0.15*SR),e): buf[i]*=(e-i)/(0.15*SR)
pk=max(abs(x) for x in buf) or 1.0
w=wave.open('mix.wav','wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
w.writeframes(b''.join(struct.pack('<h',int(max(-1,min(1,x/pk*0.9))*32767)) for x in buf)); w.close(); print('mix.wav',DUR,'s')
